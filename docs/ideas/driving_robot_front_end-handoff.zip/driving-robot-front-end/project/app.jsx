// driving_robot wireframes — main app
// Composes all variations on a DesignCanvas with a state-cycling Tweaks panel

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "state": "READY"
}/*EDITMODE-END*/;

const W = 1200;
const H = 740;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const state = t.state;

  return (
    <>
      <TweaksPanel>
        <TweakSection label="システム状態">
          <div style={{ fontSize: 12, color: '#666', marginBottom: 8 }}>
            すべてのアートボードのシステム状態を切替えてバッジ色・モニター画面の見え方を比較できます。
          </div>
          <TweakRadio
            label="State"
            value={state}
            options={['STANDBY', 'READY', 'RUNNING', 'EMERGENCY']}
            onChange={(v) => setTweak('state', v)}
          />
        </TweakSection>
      </TweaksPanel>

      <DesignCanvas>
        <DCSection id="overview" title="driving_robot — フロントエンド ワイヤーフレーム"
          subtitle="シャシダイナモ向け自動運転ロボット Web GUI · ペルソナ：実験エンジニア（初心者・シンプル操作優先） · 1920×1080デスクトップ想定 · 全画面サイドメニュー型">
          <DCArtboard id="readme" label="このワイヤーフレームについて" width={720} height={H}>
            <ReadmePanel />
          </DCArtboard>
          <DCArtboard id="navmap" label="画面遷移マップ" width={W} height={H}>
            <NavMap />
          </DCArtboard>
        </DCSection>

        {/* ① 起動・初期化 */}
        <DCSection id="init" title="① 起動・初期化 / 非常停止リセット"
          subtitle="電源ON → BOOTING → STANDBY → 初期化 → READY (UC1) / 非常停止後リセット (UC4)">
          <DCArtboard id="booting"  label="BOOTING — 通信確認中"          width={W} height={H}><BootingScreen /></DCArtboard>
          <DCArtboard id="error"    label="ERROR — 起動時通信NG"          width={W} height={H}><ErrorScreen /></DCArtboard>
          <DCArtboard id="init-a"   label="INITIALIZING — 初期化ステップ" width={W} height={H}><InitA /></DCArtboard>
          <DCArtboard id="emg-reset" label="EMERGENCY リセット画面"       width={W} height={H}><InitB /></DCArtboard>
        </DCSection>

        {/* ② 安全システム — 停止・AC断 */}
        <DCSection id="safety" title="② 安全システム — 自動停止 / AC電源断"
          subtitle="逸脱超過・過電流・CAN断による自動停止 / AC電源断シーケンス進捗">
          <DCArtboard id="ac-loss"      label="AC電源断 — 安全停止シーケンス"      width={W} height={H}><AcPowerLossScreen /></DCArtboard>
          <DCArtboard id="stop-dev"     label="自動停止 — 逸脱超過"               width={W} height={H}><AutoStopDeviationScreen /></DCArtboard>
          <DCArtboard id="stop-oc"      label="自動停止 — 過電流検知"             width={W} height={H}><AutoStopOvercurrentScreen /></DCArtboard>
          <DCArtboard id="stop-can"     label="自動停止 — CAN受信タイムアウト"    width={W} height={H}><AutoStopCanTimeoutScreen /></DCArtboard>
          <DCArtboard id="precheck-ng"  label="走行前チェック — NG詳細 + 解決ガイド" width={W} height={H}><PreCheckNGScreen /></DCArtboard>
        </DCSection>

        {/* ③ 車両プロファイル */}
        <DCSection id="profiles" title="③ 車両プロファイル管理"
          subtitle="複数車両の設定・キャリブレーション・運転モデルを管理">
          <DCArtboard id="prof-a"      label="一覧"            width={W} height={H}><ProfilesA state={state} /></DCArtboard>
          <DCArtboard id="prof-create" label="新規作成"        width={W} height={H}><ProfileCreate state={state} /></DCArtboard>
          <DCArtboard id="prof-edit"   label="編集"            width={W} height={H}><ProfileEdit state={state} /></DCArtboard>
        </DCSection>

        {/* ④ キャリブレーション */}
        <DCSection id="calibration" title="④ キャリブレーション"
          subtitle="ジョグ操作でゼロ/フル位置を手動設定。バリデーション失敗時のエラー表示含む">
          <DCArtboard id="cal-a"   label="ステップ式（1軸ずつ）"       width={W} height={H}><CalibrationA state={state} /></DCArtboard>
          <DCArtboard id="cal-err" label="バリデーション失敗 — エラー表示" width={W} height={H}><CalibrationErrorScreen /></DCArtboard>
        </DCSection>

        {/* ⑤ 走行モード */}
        <DCSection id="modes" title="⑤ 走行モード管理"
          subtitle="WLTP等の基準車速CSVをアップロード・管理">
          <DCArtboard id="mode-a"      label="一覧＋プレビュー" width={W} height={H}><ModesA state={state} /></DCArtboard>
          <DCArtboard id="mode-create" label="新規作成"         width={W} height={H}><ModeCreate state={state} /></DCArtboard>
        </DCSection>

        {/* ⑥ 自動走行モニター */}
        <DCSection id="auto" title="⑥ 自動走行モニター"
          subtitle="基準 vs 実車速リアルタイムグラフ + 逸脱量フォーカス">
          <DCArtboard id="auto-d" label="3軸グラフ + 逸脱量フォーカス" width={W} height={H}><AutoDriveD state={state} /></DCArtboard>
        </DCSection>

        {/* ⑦ 手動操作 */}
        <DCSection id="manual" title="⑦ 手動操作"
          subtitle="ジョグ操作でアクチュエータを直接制御">
          <DCArtboard id="man-jog" label="ジョグ操作" width={W} height={H}><ManualJog state={state} /></DCArtboard>
        </DCSection>

        {/* ⑧ 学習運転 + モデル学習 */}
        <DCSection id="learning" title="⑧ 学習運転 / 運転モデル学習"
          subtitle="速度×加速度グリッドで走行 → モデル学習実行中 → 完了 / ログ再学習">
          <DCArtboard id="lrn-new"    label="学習運転 — 実行中"         width={W} height={H}><LearningNew state={state} /></DCArtboard>
          <DCArtboard id="lrn-train"  label="モデル学習 — 実行中"       width={W} height={H}><ModelTrainingScreen /></DCArtboard>
          <DCArtboard id="lrn-done"   label="モデル学習 — 完了"         width={W} height={H}><ModelTrainingDoneScreen /></DCArtboard>
          <DCArtboard id="lrn-retrain" label="ログからモデル再学習 — ログ選択" width={W} height={H}><RetrainSelectLogScreen /></DCArtboard>
        </DCSection>

        {/* ⑨ タイムスケジュール (Post-MVP P1) */}
        <DCSection id="schedule" title="⑨ タイムスケジュール (Post-MVP · P1)"
          subtitle="時刻×開度の表形式でアクチュエータを自動制御。基準車速CSVなしで動作可能。">
          <DCArtboard id="sched-list" label="一覧"   width={W} height={H}><TimeScheduleListScreen state={state} /></DCArtboard>
          <DCArtboard id="sched-edit" label="編集"   width={W} height={H}><TimeScheduleEditScreen state={state} /></DCArtboard>
        </DCSection>

        {/* ⑩ シーケンス (Post-MVP P1) */}
        <DCSection id="sequence" title="⑩ シーケンス (Post-MVP · P1)"
          subtitle="走行モード＋タイムスケジュールを任意の順序で組み合わせて連続実行">
          <DCArtboard id="seq-list" label="一覧"   width={W} height={H}><SequenceListScreen state={state} /></DCArtboard>
          <DCArtboard id="seq-edit" label="編集"   width={W} height={H}><SequenceEditScreen state={state} /></DCArtboard>
        </DCSection>

        {/* ⑪ ログ管理 */}
        <DCSection id="logs" title="⑪ ログ管理・確認">
          <DCArtboard id="log-a" label="セッション一覧（詳細ボタンで詳細表示）" width={W} height={H}><LogsA state={state} /></DCArtboard>
          <DCArtboard id="log-b" label="セッション詳細"                         width={W} height={H}><LogsB state={state} /></DCArtboard>
          <DCArtboard id="log-c" label="ストレージ管理"                         width={W} height={H}><LogsC state={state} /></DCArtboard>
        </DCSection>

        <DCPostIt x={40} y={-60} rotate={-2}>
          右下 Tweaks でシステム状態を切替。<br/>
          ⑪ログ → 詳細ボタンで詳細グラフへ遷移。<br/>
          アートボードは ⤢ で全画面表示・グリップでドラッグ並べ替え可。
        </DCPostIt>
      </DesignCanvas>
    </>
  );
}

function ReadmePanel() {
  return (
    <div style={{
      width: '100%', height: '100%', padding: 36,
      background: PAPER, fontFamily: "'Patrick Hand', 'Kalam', 'Comic Sans MS', cursive",
      display: 'flex', flexDirection: 'column', gap: 14, color: INK,
      overflow: 'hidden',
    }}>
      <div style={{ fontSize: 32, fontWeight: 800, letterSpacing: 0.5 }}>driving_robot</div>
      <div style={{ fontSize: 17, color: INK_SOFT, marginTop: -8 }}>シャシダイナモ向け自動運転ロボット — Web GUI ワイヤーフレーム探索</div>
      <div style={{ borderTop: `1px solid ${INK}`, margin: '4px 0' }} />
      <Section label="目的">
        要求定義と機能設計に基づき、フロントエンドの方向性を素早く幅広く探るためのワイヤーフレームです。
        UI構造・情報レイアウト・操作起点の比較が主目的で、視覚的な仕上げは意図的に低密度にしています。
      </Section>
      <Section label="システム前提">
        Raspberry Pi 5 上のFastAPI + WebSocket / Modbus RTU × 2軸 / Kvaser USB-CAN / Postgres /
        AC UPS / 非常停止 ×2。50ms制御ループ・100msログ・追従精度 ±0.2 km/h (P95)。
      </Section>
      <Section label="ナビゲーション構造">
        左固定サイドメニュー（180px）＋ 上部ステータスバー。
        メニュー：ダッシュボード / 初期化 / 車両プロファイル / キャリブレーション / 走行モード /
        自動走行 / 手動操作 / 学習運転 / ログ。
      </Section>
      <Section label="探索した観点">
        ・情報密度（モニター重視 vs ミニマル）<br/>
        ・初心者向けランチャー vs エンジニア向け情報密集<br/>
        ・ペダル表現（縦バー / 横バー / ダイヤル / 計器盤）<br/>
        ・キャリブレーション操作（ステップ / 並列 / コンソール / 1画面）<br/>
        ・グラフ中心配置とリアルタイム指標の重みづけ
      </Section>
      <Section label="使い方のヒント">
        ・各アートボードを ⤢ で全画面表示できます<br/>
        ・タイトル・ラベルをクリックして直接編集できます<br/>
        ・右下 Tweaks で「システム状態」を切替えると、ダッシュボードや自動走行画面のバッジ色が変わります<br/>
        ・気に入った案を選んでフィードバックしてください — 次フェーズで肉付けします
      </Section>
    </div>
  );
}

function Section({ label, children }) {
  return (
    <div>
      <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 2 }}>{label}</div>
      <div style={{ fontSize: 15, color: INK_SOFT, lineHeight: 1.6 }}>{children}</div>
    </div>
  );
}

function NavMap() {
  // Sketchy navigation/state diagram
  const screens = [
    ['init', '初期化', 100, 280],
    ['dash', 'ダッシュボード', 300, 280],
    ['prof', 'プロファイル', 540, 100],
    ['cal', 'キャリブレーション', 760, 100],
    ['mode', '走行モード', 540, 480],
    ['auto', '自動走行モニター', 760, 480],
    ['man', '手動操作', 540, 280],
    ['lrn', '学習運転', 760, 280],
    ['log', 'ログ', 1000, 280],
    ['emg', 'EMERGENCY', 300, 540],
  ];
  const edges = [
    ['init', 'dash'], ['dash', 'prof'], ['prof', 'cal'],
    ['dash', 'mode'], ['mode', 'auto'], ['dash', 'man'],
    ['dash', 'lrn'], ['dash', 'log'], ['auto', 'log'],
    ['auto', 'emg'], ['man', 'emg'], ['lrn', 'emg'], ['emg', 'dash'],
  ];
  const byId = Object.fromEntries(screens.map(s => [s[0], s]));
  return (
    <div style={{
      width: '100%', height: '100%', background: PAPER, padding: 30, position: 'relative',
      fontFamily: "'Patrick Hand', 'Kalam', cursive",
    }}>
      <div style={{ fontSize: 26, fontWeight: 800 }}>画面遷移マップ</div>
      <div style={{ fontSize: 14, color: INK_SOFT, marginBottom: 14 }}>左サイドメニューからどこへでも遷移可。図はユースケース上の主な流れ。</div>
      <svg viewBox="0 0 1200 660" width="100%" height="640" style={{ position: 'absolute', inset: '70px 30px 30px' }}>
        {edges.map(([a, b], i) => {
          const A = byId[a], B = byId[b];
          if (!A || !B) return null;
          const isEmg = a === 'emg' || b === 'emg';
          return (
            <g key={i}>
              <path
                d={`M ${A[2] + 70} ${A[3] + 22} Q ${(A[2] + B[2]) / 2 + 30} ${(A[3] + B[3]) / 2 - 20} ${B[2] - 5} ${B[3] + 22}`}
                fill="none" stroke={isEmg ? '#a23232' : INK} strokeWidth="1.4"
                strokeDasharray={isEmg ? '4 3' : '0'} markerEnd="url(#arr)" />
            </g>
          );
        })}
        <defs>
          <marker id="arr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
            <path d="M 0 0 L 10 5 L 0 10 z" fill={INK} />
          </marker>
        </defs>
        {screens.map(([id, label, x, y]) => {
          const emg = id === 'emg';
          const init = id === 'init';
          return (
            <g key={id}>
              <rect x={x} y={y} width="160" height="44"
                fill={emg ? '#f1d8d2' : init ? '#e9e7e1' : PAPER}
                stroke={emg ? '#a23232' : INK}
                strokeWidth={id === 'dash' ? 2.4 : 1.5}
                rx="6" />
              <text x={x + 80} y={y + 28} fontSize="16" textAnchor="middle"
                fontFamily="'Patrick Hand', cursive"
                fontWeight={id === 'dash' ? 800 : 600}
                fill={emg ? '#5e1414' : INK}>{label}</text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}

Object.assign(window, { App });

// Mount
ReactDOM.createRoot(document.getElementById('root')).render(<App />);
