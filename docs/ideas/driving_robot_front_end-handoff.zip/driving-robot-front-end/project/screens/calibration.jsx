// Calibration — 4 variations
// Big +/- buttons + keyboard shortcut hints

function JogKey({ label, sub, big }) {
  return (
    <div style={{
      width: big ? 84 : 60, height: big ? 84 : 60,
      border: `2px solid ${INK}`, borderRadius: 8,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      background: PAPER, boxShadow: '2px 2px 0 rgba(0,0,0,0.15)',
      fontWeight: 700,
    }}>
      <div style={{ fontSize: big ? 30 : 22 }}>{label}</div>
      {sub && <div style={{ fontSize: 11, color: INK_SOFT }}>{sub}</div>}
    </div>
  );
}

// Position ruler — visual current/zero/full
function PosRuler({ current = 2400, zero = 800, full = 4200, width = 360 }) {
  const min = 0, max = 5000;
  const p = (v) => ((v - min) / (max - min)) * width;
  return (
    <svg viewBox={`0 0 ${width} 64`} width={width} height={64} style={{ display: 'block' }}>
      <rect x="0" y="28" width={width} height="14" fill={PAPER_2} stroke={INK} strokeWidth="1.2" />
      {[0, 1000, 2000, 3000, 4000, 5000].map(v => (
        <g key={v}>
          <line x1={p(v)} y1="24" x2={p(v)} y2="46" stroke={INK_SOFT} strokeWidth="1" />
          <text x={p(v)} y="60" fontSize="10" fontFamily="monospace" textAnchor="middle" fill={INK_SOFT}>{v}</text>
        </g>
      ))}
      {/* zero marker */}
      <g>
        <line x1={p(zero)} y1="14" x2={p(zero)} y2="46" stroke="#3f6b3f" strokeWidth="2" />
        <text x={p(zero)} y="10" fontSize="11" textAnchor="middle" fontFamily="inherit" fill="#3f6b3f">ZERO</text>
      </g>
      {/* full marker */}
      <g>
        <line x1={p(full)} y1="14" x2={p(full)} y2="46" stroke="#a23232" strokeWidth="2" />
        <text x={p(full)} y="10" fontSize="11" textAnchor="middle" fontFamily="inherit" fill="#a23232">FULL</text>
      </g>
      {/* current */}
      <polygon points={`${p(current)},20 ${p(current) - 6},14 ${p(current) + 6},14`} fill={INK} />
      <line x1={p(current)} y1="20" x2={p(current)} y2="46" stroke={INK} strokeWidth="2" />
      <text x={p(current)} y="56" fontSize="10" textAnchor="middle" fontFamily="monospace" fill={INK}>{current}</text>
    </svg>
  );
}

// ── C1 Step-by-step — ManualJog レイアウトベース
function CalibrationA({ state }) {

  const AxisCal = ({ axis, color, current, zero, full, stepDone, stepNow }) => (
    <Box label={axis} style={{ padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: 10 }}>
      {/* 位置ルーラー */}
      <PosRuler current={current} zero={zero} full={full} width={460} />

      {/* ジョグボタン + 現在位置 */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <JogKey label="−10" sub="Shift+←" big />
        <JogKey label="−1"  sub="←"       big />
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1 }}>
          <div style={{ fontSize: 12, color: INK_SOFT }}>現在位置</div>
          <div style={{ fontSize: 32, fontFamily: 'monospace', fontWeight: 800, lineHeight: 1 }}>{current}</div>
          <div style={{ fontSize: 11, color: INK_SOFT }}>pulse</div>
        </div>
        <JogKey label="+1"  sub="→"       big />
        <JogKey label="+10" sub="Shift+→" big />
      </div>

      {/* ZERO / FULL 確定ボタン */}
      <div style={{ display: 'flex', gap: 8 }}>
        <Btn style={{ flex: 1, borderColor: '#3f6b3f', color: '#22421f', justifyContent: 'center' }}>
          ZERO 確定 [Z]
        </Btn>
        <Btn style={{ flex: 1, borderColor: '#a23232', color: '#5e1414', justifyContent: 'center' }}>
          FULL 確定 [F]
        </Btn>
      </div>

      {/* 記録値 */}
      <div style={{ display: 'flex', gap: 18, fontSize: 13, color: INK_SOFT }}>
        <span>ZERO <b style={{ fontFamily: 'monospace', color: zero ? INK : INK_MUTE }}>{zero ?? '—'}</b></span>
        <span>FULL <b style={{ fontFamily: 'monospace', color: full ? INK : INK_MUTE }}>{full ?? '—'}</b></span>
        <span>STROKE <b style={{ fontFamily: 'monospace', color: (zero && full) ? INK : INK_MUTE }}>{(zero && full) ? full - zero : '—'}</b></span>
        <div style={{ flex: 1 }} />
        <Btn>原点へ戻す</Btn>
      </div>
    </Box>
  );

  return (
    <Frame state={state || 'READY'} screen="キャリブレーション" activeNav="calibration">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, height: '100%' }}>

        {/* ステップ進捗バー */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          {['ブレーキ ZERO', 'ブレーキ FULL', 'アクセル ZERO', 'アクセル FULL', '確定・保存'].map((s, i) => (
            <React.Fragment key={s}>
              <div style={{
                display: 'flex', alignItems: 'center', gap: 6, fontSize: 13,
                padding: '4px 12px', borderRadius: 14,
                border: `1.4px solid ${i === 1 ? INK : INK_MUTE}`,
                background: i === 1 ? PAPER_2 : 'transparent',
                fontWeight: i === 1 ? 700 : 400,
                color: i < 1 ? INK_SOFT : INK,
                whiteSpace: 'nowrap',
              }}>
                {i < 1
                  ? <span style={{ color: '#3f6b3f' }}>✓</span>
                  : <span style={{ fontFamily: 'monospace', fontSize: 12 }}>{i + 1}</span>}
                <span>{s}</span>
              </div>
              {i < 4 && <div style={{ flex: 1, height: 1, background: INK_MUTE, minWidth: 8 }} />}
            </React.Fragment>
          ))}
        </div>

        {/* 2軸 + 下段を1グリッドに統合 */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gridTemplateRows: '1fr auto',
          gap: 10,
          flex: 1,
          minHeight: 0,
        }}>
          {/* 上段左: ブレーキ */}
          <AxisCal
            axis="ブレーキ" color={INK}
            current={3950} zero={820} full={null}
          />
          {/* 上段右: アクセル */}
          <AxisCal
            axis="アクセル" color="#a23232"
            current={650} zero={null} full={null}
          />

          {/* 下段左: キーボードショートカット */}
          <Box label="キーボードショートカット" style={{ padding: 12 }}>
            <div style={{ fontSize: 13, lineHeight: 1.9, fontFamily: 'monospace' }}>
              <div>← / →        : ±1 pulse</div>
              <div>Shift+← / →  : ±10 pulse</div>
              <div>Z             : ZERO 確定</div>
              <div>F             : FULL 確定</div>
              <div>Tab           : 軸切替 (アクセル ↔ ブレーキ)</div>
              <div>Space         : この位置で確定</div>
              <div>Esc           : キャンセル</div>
            </div>
            <Note style={{ marginTop: 8 }}>キャリブレーション中は最大開度設定が無視されます。電流値を常時監視中。</Note>
          </Box>

          {/* 下段右: 記録済み進捗 + 保存ボタン */}
          <div style={{ display: 'flex', gap: 10, alignItems: 'stretch' }}>
            <Box label="記録済み" style={{ padding: '10px 14px', fontSize: 13, flex: 1 }}>
              <Row cells={[['', '22px'], ['軸', '1.4fr'], ['ZERO', '1fr', 'mono'], ['FULL', '1fr', 'mono']]} header />
              <Row cells={[['✓', '22px'], ['ブレーキ', '1.4fr'], ['820', '1fr', 'mono'], ['—', '1fr', 'mono']]} />
              <Row cells={[['●', '22px'], ['アクセル', '1.4fr'], ['',   '1fr', 'mono'], ['—', '1fr', 'mono']]} style={{ background: PAPER_2 }} />
            </Box>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, flex: 1 }}>
              <Btn primary big style={{ flex: 1 }}>キャリブレーション<br/>保存</Btn>
            </div>
          </div>
        </div>

      </div>
    </Frame>
  );
}

// ── C2 Side-by-side — both axes at once
function CalibrationB({ state }) {
  const AxisPanel = ({ axis, color, zero, full, current }) => (
    <Box label={`${axis} · ゼロ/フル設定`} style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 12 }}>
      <PosRuler current={current} zero={zero} full={full} width={460} />
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', justifyContent: 'center' }}>
        <JogKey label="−10" sub="Shift+←" />
        <JogKey label="−1" sub="←" big />
        <div style={{ width: 110, textAlign: 'center' }}>
          <div style={{ fontSize: 11, color: INK_SOFT }}>現在位置</div>
          <div style={{ fontSize: 28, fontFamily: 'monospace', fontWeight: 700 }}>{current}</div>
        </div>
        <JogKey label="+1" sub="→" big />
        <JogKey label="+10" sub="Shift+→" />
      </div>
      <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
        <Btn style={{ borderColor: '#3f6b3f', color: '#22421f' }}>ZERO ここで確定</Btn>
        <Btn style={{ borderColor: '#a23232', color: '#5e1414' }}>FULL ここで確定</Btn>
      </div>
      <div style={{ display: 'flex', gap: 10, fontSize: 13, color: INK_SOFT, justifyContent: 'space-around' }}>
        <span>zero: <b style={{ fontFamily: 'monospace' }}>{zero || '—'}</b></span>
        <span>full: <b style={{ fontFamily: 'monospace' }}>{full || '—'}</b></span>
        <span>stroke: <b style={{ fontFamily: 'monospace' }}>{full && zero ? full - zero : '—'}</b></span>
      </div>
    </Box>
  );
  return (
    <Frame state={state || 'READY'} screen="キャリブレーション · 並列" activeNav="calibration">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, height: '100%' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <H2 sub="アクセル・ブレーキを独立して設定。Tabキーで選択軸を切り替えます。">キャリブレーション</H2>
          <div style={{ flex: 1 }} />
          <Btn>原点復帰</Btn>
          <Btn primary big>バリデーション → 保存</Btn>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, flex: 1 }}>
          <AxisPanel axis="アクセル" color={INK} zero={820} full={4180} current={2400} />
          <AxisPanel axis="ブレーキ" color="#a23232" zero={650} full={null} current={1800} />
        </div>
        <Box style={{ display: 'flex', gap: 14, alignItems: 'center', padding: '10px 14px', fontSize: 13 }}>
          <span><b>現在の軸:</b> アクセル</span>
          <span>電流値 (acc): <b style={{ fontFamily: 'monospace' }}>432 mA</b></span>
          <span>電流値 (brk): <b style={{ fontFamily: 'monospace' }}>185 mA</b></span>
          <span style={{ flex: 1 }} />
          <Pill>過電流監視: 緊急遮断のみ</Pill>
        </Box>
      </div>
    </Frame>
  );
}

// ── C3 Gamepad-style — large jog console
function CalibrationC({ state }) {
  return (
    <Frame state={state || 'READY'} screen="キャリブレーション · ジョグコンソール" activeNav="calibration">
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18, height: '100%' }}>
        <Box style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 16 }}>
          <H2 sub="現在の軸: アクセル / 操作モード: フル位置">ジョグコンソール</H2>
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', gap: 14 }}>
            <div style={{ fontSize: 14, color: INK_SOFT }}>現在位置 [pulse]</div>
            <div style={{ fontSize: 88, fontFamily: 'monospace', fontWeight: 800, lineHeight: 1 }}>3,950</div>
            <PosRuler current={3950} zero={820} full={4180} width={420} />
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 80px)', gap: 12, marginTop: 14 }}>
              <JogKey label="◀◀" sub="−10" big />
              <JogKey label="◀" sub="−1" big />
              <JogKey label="▶" sub="+1" big />
              <JogKey label="▶▶" sub="+10" big />
            </div>
            <div style={{ display: 'flex', gap: 14, marginTop: 16 }}>
              <Btn big style={{ borderColor: '#3f6b3f', color: '#22421f', padding: '12px 24px' }}>ZERO 確定 [Z]</Btn>
              <Btn big style={{ borderColor: '#a23232', color: '#5e1414', padding: '12px 24px' }}>FULL 確定 [F]</Btn>
            </div>
          </div>
        </Box>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Box label="進捗">
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                ['アクセル ゼロ', 820, true],
                ['アクセル フル', null, 'now'],
                ['ブレーキ ゼロ', null, false],
                ['ブレーキ フル', null, false],
              ].map(([l, v, st]) => (
                <div key={l} style={{
                  display: 'flex', alignItems: 'center', gap: 10,
                  padding: '8px 12px',
                  border: st === 'now' ? `1.5px solid ${INK}` : `1px dashed ${INK_MUTE}`,
                  background: st === 'now' ? PAPER_2 : 'transparent',
                  borderRadius: 4,
                }}>
                  <div style={{
                    width: 22, height: 22, borderRadius: '50%',
                    border: `1.4px solid ${st === true ? '#3f6b3f' : st === 'now' ? INK : INK_MUTE}`,
                    background: st === true ? '#dfeadc' : 'transparent',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700,
                  }}>{st === true ? '✓' : st === 'now' ? '●' : ''}</div>
                  <div style={{ flex: 1, fontSize: 15 }}>{l}</div>
                  <div style={{ fontFamily: 'monospace', fontSize: 14, color: v ? INK : INK_MUTE }}>{v ?? '—'}</div>
                </div>
              ))}
            </div>
          </Box>
          <Box label="軸切替">
            <div style={{ display: 'flex', gap: 8 }}>
              <Btn primary>アクセル</Btn>
              <Btn>ブレーキ</Btn>
            </div>
          </Box>
          <Box label="キーボード">
            <div style={{ fontFamily: 'monospace', fontSize: 13, lineHeight: 1.9 }}>
              ← → : ジョグ1<br/>
              Shift+← → : ジョグ10<br/>
              Z : ゼロ確定 / F : フル確定<br/>
              Tab : 軸切替 / Esc : キャンセル
            </div>
          </Box>
        </div>
      </div>
    </Frame>
  );
}

// ── C4 Compact — single-screen overview with inline jog
function CalibrationD({ state }) {
  return (
    <Frame state={state || 'READY'} screen="キャリブレーション · コンパクト" activeNav="calibration">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <H2 sub="プロファイル「Prius_2024」のキャリブレーション">キャリブレーション</H2>
        {['アクセル', 'ブレーキ'].map((axis, idx) => (
          <Box key={axis} label={`${idx + 1}. ${axis}`} style={{ padding: 14 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr auto auto auto auto', gap: 14, alignItems: 'center' }}>
              <PosRuler current={idx === 0 ? 3950 : 1800} zero={idx === 0 ? 820 : 650} full={idx === 0 ? 4180 : null} width={460} />
              <div style={{ display: 'flex', gap: 6 }}>
                <JogKey label="◀" sub="←" />
                <JogKey label="▶" sub="→" />
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 11, color: INK_SOFT }}>pulse</div>
                <div style={{ fontSize: 26, fontFamily: 'monospace', fontWeight: 700 }}>{idx === 0 ? 3950 : 1800}</div>
              </div>
              <Btn style={{ borderColor: '#3f6b3f' }}>ZERO 確定</Btn>
              <Btn style={{ borderColor: '#a23232' }}>FULL 確定</Btn>
            </div>
            <div style={{ display: 'flex', gap: 18, fontSize: 13, color: INK_SOFT, marginTop: 8, paddingLeft: 4 }}>
              <span>ZERO <b style={{ fontFamily: 'monospace', color: INK }}>{idx === 0 ? 820 : 650}</b></span>
              <span>FULL <b style={{ fontFamily: 'monospace', color: INK }}>{idx === 0 ? 4180 : '—'}</b></span>
              <span>STROKE <b style={{ fontFamily: 'monospace', color: INK }}>{idx === 0 ? 3360 : '—'}</b></span>
              <span style={{ flex: 1 }} />
              <span>電流 <b style={{ fontFamily: 'monospace', color: INK }}>{idx === 0 ? 432 : 185} mA</b></span>
              <span>状態 <Pill style={{ marginLeft: 4 }}>{idx === 0 ? '部分完了' : '未'}</Pill></span>
            </div>
          </Box>
        ))}
        <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
          <Btn>原点復帰</Btn>
          <Btn>キャンセル</Btn>
          <Btn primary big>バリデーション → プロファイル保存</Btn>
        </div>
      </div>
    </Frame>
  );
}

Object.assign(window, { CalibrationA, CalibrationB, CalibrationC, CalibrationD, JogKey });
