// Dashboard — 5 variations
// State is passed in via props.state (cycled from Tweaks panel)

// ── D1 Classic — speed dial + gauges + graph + actions
function DashboardA({ state }) {
  return (
    <Frame state={state} screen="ダッシュボード" activeNav="dashboard">
      <div style={{ display: 'grid', gridTemplateColumns: '300px 1fr 220px', gap: 18, height: '100%' }}>
        <Box label="現在の状態" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <BigSpeed value={62.4} refSpeed={60.0} size={220} />
          <div style={{ display: 'flex', justifyContent: 'space-around', marginTop: 6 }}>
            <PedalGauge label="アクセル" value={42.3} height={120} width={48} />
            <PedalGauge label="ブレーキ" value={0} height={120} width={48} color="#a23232" />
          </div>
        </Box>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Box label="基準 vs 実車速 (リアルタイム)" style={{ padding: 8 }}>
            <SpeedGraph width="100%" height={250} progress={0.42} />
          </Box>
          <Box label="走行情報">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, fontSize: 14 }}>
              <div>走行モード: <b>WLTP_Class3</b></div>
              <div>セッション開始: <span style={{ fontFamily: 'monospace' }}>13:42:08</span></div>
              <div>逸脱量: <b style={{ fontFamily: 'monospace' }}>+0.18 km/h</b></div>
              <div>累積走行: <span style={{ fontFamily: 'monospace' }}>6m 12s / 30m</span></div>
            </div>
          </Box>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <Btn primary big>▶ 自動走行 開始</Btn>
          <Btn big>学習運転</Btn>
          <Btn big>手動操作</Btn>
          <Btn>初期化</Btn>
          <div style={{ flex: 1 }} />
          <EmergencyBtn size={110} style={{ alignSelf: 'center' }} />
        </div>
      </div>
    </Frame>
  );
}

// ── D2 Data-dense — everything visible, monitoring focus
function DashboardB({ state }) {
  return (
    <Frame state={state} screen="ダッシュボード · モニター重視" activeNav="dashboard">
      <div style={{ display: 'grid', gridTemplateRows: 'auto 1fr auto', gap: 14, height: '100%' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 12 }}>
          {[
            ['実車速 [km/h]', '62.4'],
            ['基準 [km/h]', '60.0'],
            ['偏差 [km/h]', '+0.18'],
            ['アクセル [%]', '42.3'],
            ['ブレーキ [%]', '0.0'],
          ].map(([l, v]) => (
            <Box key={l} style={{ textAlign: 'center', padding: '10px 6px' }}>
              <div style={{ fontSize: 12, color: INK_SOFT }}>{l}</div>
              <div style={{ fontSize: 30, fontWeight: 700, fontFamily: 'monospace', lineHeight: 1.1 }}>{v}</div>
            </Box>
          ))}
        </div>
        <Box label="基準 vs 実車速  ―  逸脱量グラフ" style={{ padding: 10 }}>
          <SpeedGraph width="100%" height={260} progress={0.42} />
          <div style={{ borderTop: `1px dashed ${INK_MUTE}`, marginTop: 6, paddingTop: 4 }}>
            <Squig width="100%" />
          </div>
          <div style={{ fontSize: 12, color: INK_SOFT, fontFamily: 'monospace', textAlign: 'center' }}>↑ deviation [km/h]   ±2.0 で自動停止</div>
        </Box>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', gap: 8 }}>
            <Pill accent="RUNNING">自動走行中</Pill>
            <Pill>WLTP_Class3</Pill>
            <Pill>Prius_2024</Pill>
            <Pill>セッション #2483</Pill>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <Btn>一時停止</Btn>
            <Btn danger big>■ 停止</Btn>
          </div>
        </div>
      </div>
    </Frame>
  );
}

// ── D3 Card grid — feature launcher style for novices
function DashboardC({ state }) {
  const cards = [
    ['初期化', '通信確認 + サーボON', '〜30s'],
    ['プロファイル選択', '車両プロファイルを選ぶ', 'READY状態'],
    ['キャリブレーション', 'ペダル ゼロ/フル 設定', '〜60s'],
    ['学習運転', 'モデル取得用走行', '〜20分'],
    ['自動走行', '基準車速CSVに追従', 'モード選択'],
    ['手動操作', 'スライダーで動作確認', 'いつでも'],
    ['ログ確認', '過去3ヶ月の走行ログ', 'CSV DL可'],
    ['設定', 'PIDゲイン / 閾値', '上級者向け'],
  ];
  return (
    <Frame state={state} screen="ダッシュボード · ランチャー" activeNav="dashboard">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16, height: '100%' }}>
        <Box style={{ display: 'flex', alignItems: 'center', gap: 18, padding: '14px 18px' }}>
          <BigSpeed value={0} size={120} />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 20, fontWeight: 700 }}>こんにちは。走行を開始しますか？</div>
            <div style={{ fontSize: 14, color: INK_SOFT, marginTop: 4 }}>
              下のカードから操作を選ぶか、サイドメニューからどうぞ。
            </div>
          </div>
          <EmergencyBtn size={100} />
        </Box>
        <div style={{
          flex: 1,
          display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gridTemplateRows: '1fr 1fr', gap: 14,
        }}>
          {cards.map(([title, desc, hint], i) => (
            <Box key={title} thick={i < 3} tint={i < 3 ? '#f4f1e6' : undefined}
              style={{ display: 'flex', flexDirection: 'column', gap: 6, cursor: 'pointer' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{
                  width: 26, height: 26, border: `1.4px solid ${INK}`,
                  borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 13, fontWeight: 700,
                }}>{i + 1}</div>
                <div style={{ fontSize: 17, fontWeight: 700 }}>{title}</div>
              </div>
              <div style={{ fontSize: 13, color: INK_SOFT, flex: 1 }}>{desc}</div>
              <div style={{ fontSize: 12, color: INK_MUTE, fontFamily: 'monospace' }}>{hint}</div>
            </Box>
          ))}
        </div>
      </div>
    </Frame>
  );
}

// ── D4 Cockpit — driving-style instruments
function DashboardD({ state }) {
  return (
    <Frame state={state} screen="ダッシュボード · コックピット" activeNav="dashboard">
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr 1fr', gap: 18, height: '100%' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12, alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ fontSize: 13, color: INK_SOFT }}>アクセル</div>
          <PedalGauge label="" value={42.3} height={220} width={70} />
          <Btn ghost>—</Btn>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14, justifyContent: 'center', alignItems: 'center' }}>
          <div style={{
            border: `2.5px solid ${INK}`, borderRadius: '50%',
            width: 280, height: 280,
            display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
            background: PAPER,
            boxShadow: 'inset 0 0 0 8px ' + PAPER + ', inset 0 0 0 9px ' + INK,
            position: 'relative',
          }}>
            <div style={{ fontSize: 14, color: INK_SOFT }}>実車速</div>
            <div style={{ fontSize: 110, fontWeight: 800, lineHeight: 1, fontFamily: 'inherit' }}>62</div>
            <div style={{ fontSize: 20, color: INK_SOFT }}>km/h</div>
            <div style={{ fontSize: 13, color: INK_SOFT, fontFamily: 'monospace' }}>ref 60.0 · Δ +0.18</div>
            {/* tick marks */}
            <svg style={{ position: 'absolute', inset: 0 }} viewBox="0 0 280 280">
              {Array.from({ length: 13 }, (_, i) => {
                const a = (-210 + (i * 240) / 12) * Math.PI / 180;
                const r1 = 130, r2 = 120;
                const cx = 140, cy = 140;
                return <line key={i}
                  x1={cx + Math.cos(a) * r1} y1={cy + Math.sin(a) * r1}
                  x2={cx + Math.cos(a) * r2} y2={cy + Math.sin(a) * r2}
                  stroke={INK} strokeWidth="1.5" />;
              })}
            </svg>
          </div>
          <Box label="基準車速トレース" style={{ width: '100%', padding: 6 }}>
            <SpeedGraph width="100%" height={140} progress={0.42} simple />
          </Box>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12, alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ fontSize: 13, color: INK_SOFT }}>ブレーキ</div>
          <PedalGauge label="" value={0} height={220} width={70} color="#a23232" />
          <Btn ghost>—</Btn>
        </div>
      </div>
    </Frame>
  );
}

// ── D5 Standby — STANDBY/READY focused, prechecks visible
function DashboardE({ state }) {
  const checks = [
    ['ttyUSB0 (アクセル)', true],
    ['ttyUSB1 (ブレーキ)', true],
    ['CAN (シャシダイナモ)', true],
    ['サーボ状態', true],
    ['キャリブレーション', true],
    ['プロファイル選択', true],
    ['UPS残量', true],
    ['アクチュエータ位置', false],
  ];
  return (
    <Frame state="STANDBY" screen="ダッシュボード · 起動待機" activeNav="dashboard">
      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 22, height: '100%' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18, justifyContent: 'center' }}>
          <div style={{ fontSize: 38, fontWeight: 800, lineHeight: 1.1 }}>システム待機中</div>
          <div style={{ fontSize: 16, color: INK_SOFT, maxWidth: 460 }}>
            電源ONを検出。通信確認は完了しました。<br/>
            走行を開始するには「初期化」を押してアラームリセット → サーボONを行ってください。
          </div>
          <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginTop: 10 }}>
            <Btn primary big style={{ padding: '14px 38px' }}>▶ 初期化を開始</Btn>
            <Btn big>プロファイル選択</Btn>
          </div>
          <Note style={{ maxWidth: 460 }}>
            前回は正常終了 — 原点復帰はスキップされます。
          </Note>
        </div>
        <Box label="走行前チェック" style={{ padding: '16px 18px' }}>
          <H2 sub="6項目すべてパスで走行可能">ステータス</H2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {checks.map(([l, ok]) => (
              <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 15 }}>
                <div style={{
                  width: 22, height: 22, borderRadius: '50%',
                  border: `1.4px solid ${ok ? '#3f6b3f' : INK_MUTE}`,
                  background: ok ? '#dfeadc' : 'transparent',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontWeight: 700, fontSize: 13,
                  color: ok ? '#22421f' : INK_MUTE,
                }}>{ok ? '✓' : '—'}</div>
                <div style={{ flex: 1 }}>{l}</div>
                <div style={{ fontSize: 12, fontFamily: 'monospace', color: INK_SOFT }}>{ok ? 'OK' : 'pending'}</div>
              </div>
            ))}
          </div>
        </Box>
      </div>
    </Frame>
  );
}

Object.assign(window, { DashboardA, DashboardB, DashboardC, DashboardD, DashboardE });
