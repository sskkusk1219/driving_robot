// Profile management — 3 variations

function ProfilesA({ state }) {
  const profiles = [
    ['Prius_2024', 80, 70, 180, true, true, true],
    ['Corolla_Hybrid', 75, 70, 165, true, true, false],
    ['LeafEV_2023', 85, 75, 145, true, false, false],
    ['Civic_TypeR', 90, 80, 270, false, false, false],
    ['DemoCar_test01', 60, 60, 100, true, true, true],
  ];
  return (
    <Frame state={state || 'READY'} screen="車両プロファイル · 一覧" activeNav="profiles">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, height: '100%' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <H2 sub="車両ごとのキャリブレーション・モデル・PIDゲインを管理します">車両プロファイル</H2>
          <div style={{ flex: 1 }} />
          <Btn>インポート</Btn>
          <Btn primary big>+ 新規プロファイル</Btn>
        </div>
        <Box style={{ padding: 0 }}>
          <Row cells={[
            ['', '40px'], ['名前', '2fr'], ['最大開度 (acc/brk)', '1.4fr', 'mono'],
            ['最高車速', '1fr', 'mono'], ['Kp/Ki/Kd', '1.4fr', 'mono'],
            ['キャリブ', '0.7fr'], ['モデル', '0.7fr'], ['操作', '1fr'],
          ]} header style={{ padding: '10px 14px', background: PAPER_2 }} />
          {profiles.map((p, i) => (
            <Row key={p[0]} cells={[
              [i === 0 ? '●' : '', '40px'],
              [<b key="n">{p[0]}</b>, '2fr'],
              [`${p[1]} / ${p[2]} %`, '1.4fr', 'mono'],
              [`${p[3]} km/h`, '1fr', 'mono'],
              ['1.2 / 0.05 / 0.3', '1.4fr', 'mono'],
              [p[4] ? <Pill key="c" accent="READY">OK</Pill> : <Pill key="c">未</Pill>, '0.7fr'],
              [p[5] ? <Pill key="m" accent="READY">あり</Pill> : <Pill key="m">なし</Pill>, '0.7fr'],
              [<div key="b" style={{ display: 'flex', gap: 6 }}>
                <Btn>選択</Btn><Btn>編集</Btn>
              </div>, '1fr'],
            ]} style={{ padding: '12px 14px', background: i === 0 ? '#f4f1e6' : 'transparent', borderBottom: `1px dashed ${INK_MUTE}` }} />
          ))}
        </Box>
        <div style={{ display: 'flex', gap: 12, fontSize: 13, color: INK_SOFT }}>
          <span>選択中: <b>Prius_2024</b></span>
          <span style={{ flex: 1 }} />
          <span>5件 / プロファイル数は無制限</span>
        </div>
      </div>
    </Frame>
  );
}

function ProfilesB({ state }) {
  // Split detail view
  return (
    <Frame state={state || 'READY'} screen="車両プロファイル · 詳細" activeNav="profiles">
      <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr', gap: 14, height: '100%' }}>
        <Box label="プロファイル">
          {['Prius_2024', 'Corolla_Hybrid', 'LeafEV_2023', 'Civic_TypeR', 'DemoCar_test01'].map((n, i) => (
            <div key={n} style={{
              padding: '8px 10px',
              borderLeft: i === 0 ? `3px solid ${INK}` : '3px solid transparent',
              background: i === 0 ? PAPER_2 : 'transparent',
              fontWeight: i === 0 ? 700 : 400,
              fontSize: 15,
              cursor: 'pointer',
            }}>{n}</div>
          ))}
          <div style={{ borderTop: `1px dashed ${INK_MUTE}`, margin: '8px 0' }} />
          <Btn>+ 新規</Btn>
        </Box>
        <Box label="Prius_2024 詳細" style={{ padding: 20 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <Input label="プロファイル名" value="Prius_2024" width="100%" />
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <Input label="アクセル最大開度 [%]" value="80" mono />
                <Input label="ブレーキ最大開度 [%]" value="70" mono />
                <Input label="最高車速 [km/h]" value="180" mono />
                <Input label="最大減速G [G]" value="0.6" mono />
              </div>
              <Box label="PIDゲイン" style={{ marginTop: 8 }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
                  <Input label="Kp" value="1.2" mono />
                  <Input label="Ki" value="0.05" mono />
                  <Input label="Kd" value="0.3" mono />
                </div>
              </Box>
              <Box label="停止判定">
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                  <Input label="逸脱閾値 [km/h]" value="2.0" mono />
                  <Input label="逸脱継続 [s]" value="4.0" mono />
                </div>
              </Box>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <Box label="キャリブレーションデータ">
                <Row cells={[['', '1fr'], ['ZERO', '1fr', 'mono'], ['FULL', '1fr', 'mono'], ['STROKE', '1fr', 'mono']]} header />
                <Row cells={[['アクセル', '1fr'], ['820', '1fr', 'mono'], ['4180', '1fr', 'mono'], ['3360', '1fr', 'mono']]} />
                <Row cells={[['ブレーキ', '1fr'], ['650', '1fr', 'mono'], ['3920', '1fr', 'mono'], ['3270', '1fr', 'mono']]} />
                <div style={{ fontSize: 12, color: INK_SOFT, marginTop: 6 }}>校正日: 2026-05-08 14:22</div>
              </Box>
              <Box label="運転モデル">
                <Hatch width="100%" height={120} label="learned model heatmap (speed × accel)" />
                <div style={{ fontSize: 12, color: INK_SOFT, marginTop: 6 }}>
                  data/models/Prius_2024/driving_model.pkl · 学習日 2026-05-08
                </div>
              </Box>
              <div style={{ display: 'flex', gap: 8 }}>
                <Btn>キャリブレーション →</Btn>
                <Btn>学習運転 →</Btn>
                <Btn>モデル再学習</Btn>
              </div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end', marginTop: 18 }}>
            <Btn danger>削除</Btn>
            <Btn>キャンセル</Btn>
            <Btn primary big>保存</Btn>
          </div>
        </Box>
      </div>
    </Frame>
  );
}

function ProfilesC({ state }) {
  // Card-grid style
  const profiles = ['Prius_2024', 'Corolla_Hybrid', 'LeafEV_2023', 'Civic_TypeR', 'DemoCar_test01'];
  return (
    <Frame state={state || 'READY'} screen="車両プロファイル · カード" activeNav="profiles">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, height: '100%' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <H2>車両プロファイル</H2>
          <div style={{ flex: 1 }} />
          <Btn primary big>+ 新規</Btn>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
          {profiles.map((p, i) => (
            <Box key={p} thick={i === 0} tint={i === 0 ? '#f4f1e6' : undefined}
              style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ fontSize: 18, fontWeight: 700 }}>{p}</div>
                {i === 0 && <Pill accent="READY">選択中</Pill>}
              </div>
              <Hatch width="100%" height={80} label="model heatmap" />
              <div style={{ fontSize: 13, color: INK_SOFT, lineHeight: 1.7 }}>
                最大開度: 80% / 70%<br/>
                最高車速: 180 km/h<br/>
                Kp/Ki/Kd: 1.2 / 0.05 / 0.3
              </div>
              <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
                <Pill accent="READY">校正</Pill>
                <Pill accent="READY">モデル</Pill>
              </div>
              <div style={{ display: 'flex', gap: 6, marginTop: 'auto' }}>
                <Btn>選択</Btn>
                <Btn>編集</Btn>
              </div>
            </Box>
          ))}
        </div>
      </div>
    </Frame>
  );
}

// ── Profile Form — shared by create + edit
function ProfileForm({ isNew }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18, flex: 1, minHeight: 0 }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <Box label="基本情報" style={{ padding: 18 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <Input label="プロファイル名" value={isNew ? '' : 'Prius_2024'} width="100%" />
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <Input label="アクセル最大開度 [%]" value={isNew ? '' : '80'} mono />
              <Input label="ブレーキ最大開度 [%]" value={isNew ? '' : '70'} mono />
              <Input label="最高車速 [km/h]" value={isNew ? '' : '180'} mono />
              <Input label="最大減速G [G]" value={isNew ? '' : '0.6'} mono />
            </div>
          </div>
        </Box>
        <Box label="PIDゲイン" style={{ padding: 18 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
            <Input label="Kp" value={isNew ? '' : '1.2'} mono />
            <Input label="Ki" value={isNew ? '' : '0.05'} mono />
            <Input label="Kd" value={isNew ? '' : '0.3'} mono />
          </div>
        </Box>
        <Box label="停止判定" style={{ padding: 18 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Input label="逸脱閾値 [km/h]" value={isNew ? '' : '2.0'} mono />
            <Input label="逸脱継続 [s]" value={isNew ? '' : '4.0'} mono />
          </div>
        </Box>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <Box label="キャリブレーションデータ" style={{ padding: 18 }}>
          {isNew ? (
            <div style={{ fontSize: 14, color: INK_SOFT, lineHeight: 1.8 }}>
              プロファイル保存後にキャリブレーション画面でゼロ/フル位置を設定してください。
              <div style={{ marginTop: 10 }}><Btn>キャリブレーション画面へ →</Btn></div>
            </div>
          ) : (
            <div>
              <Row cells={[['', '1fr'], ['ZERO', '1fr', 'mono'], ['FULL', '1fr', 'mono'], ['STROKE', '1fr', 'mono']]} header />
              <Row cells={[['アクセル', '1fr'], ['820', '1fr', 'mono'], ['4180', '1fr', 'mono'], ['3360', '1fr', 'mono']]} />
              <Row cells={[['ブレーキ', '1fr'], ['650', '1fr', 'mono'], ['3920', '1fr', 'mono'], ['3270', '1fr', 'mono']]} />
              <div style={{ fontSize: 12, color: INK_SOFT, marginTop: 6 }}>校正日: 2026-05-08 14:22</div>
              <div style={{ marginTop: 10 }}><Btn>キャリブレーション画面へ →</Btn></div>
            </div>
          )}
        </Box>
        <Box label="運転モデル" style={{ padding: 18 }}>
          {isNew ? (
            <div style={{ fontSize: 14, color: INK_SOFT, lineHeight: 1.8 }}>
              キャリブレーション完了後に学習運転を行いモデルを取得してください。
              <div style={{ marginTop: 10 }}><Btn>学習運転画面へ →</Btn></div>
            </div>
          ) : (
            <div>
              <Hatch width="100%" height={110} label="learned model heatmap (speed × accel)" />
              <div style={{ fontSize: 12, color: INK_SOFT, marginTop: 6 }}>data/models/Prius_2024/driving_model.pkl · 学習日 2026-05-08</div>
              <div style={{ marginTop: 10 }}><Btn>学習運転画面へ →</Btn></div>
            </div>
          )}
        </Box>
        <Note>
          {isNew
            ? 'プロファイル保存後、キャリブレーション → 学習運転の順で設定を完了させてください。'
            : 'PIDゲイン変更後は自動走行の動作を確認してください。キャリブレーションデータは保持されます。'
          }
        </Note>
        <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end', marginTop: 'auto' }}>
          {!isNew && <Btn danger>削除</Btn>}
          <Btn>キャンセル</Btn>
          <Btn primary big>{isNew ? '作成' : '保存'}</Btn>
        </div>
      </div>
    </div>
  );
}

function ProfileCreate({ state }) {
  return (
    <Frame state={state || 'READY'} screen="車両プロファイル · 新規作成" activeNav="profiles">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, height: '100%' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Btn>← 一覧に戻る</Btn>
          <H2 sub="新しい車両プロファイルを作成します">新規プロファイル作成</H2>
        </div>
        <ProfileForm isNew={true} />
      </div>
    </Frame>
  );
}

function ProfileEdit({ state }) {
  return (
    <Frame state={state || 'READY'} screen="車両プロファイル · 編集" activeNav="profiles">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, height: '100%' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Btn>← 一覧に戻る</Btn>
          <H2 sub="プロファイル「Prius_2024」を編集します">プロファイル編集</H2>
        </div>
        <ProfileForm isNew={false} />
      </div>
    </Frame>
  );
}

// ── Modes — 3 variations
function ModesA({ state }) {
  const modes = [
    ['WLTP_Class3', 1800, 131, '国際標準'],
    ['NEDC', 1180, 120, '欧州旧'],
    ['JC08', 1204, 81.6, '日本国内'],
    ['Custom_City_A', 600, 60, 'カスタム'],
    ['Highway_120', 900, 130, 'カスタム'],
  ];
  return (
    <Frame state={state || 'READY'} screen="走行モード · 一覧" activeNav="modes">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, height: '100%' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <H2 sub="基準車速CSVをアップロードして管理。自動走行で選択します。">走行モード</H2>
          <div style={{ flex: 1 }} />
          <Btn big>＋ 新規作成</Btn>
        </div>
        <Box style={{ padding: 0 }}>
          <Row cells={[
            ['名前', '2fr'], ['説明', '1.5fr'], ['長さ', '1fr', 'mono'],
            ['最高車速', '1fr', 'mono'], ['プレビュー', '2fr'], ['操作', '1fr'],
          ]} header style={{ padding: '10px 14px', background: PAPER_2 }} />
          {modes.map((m, i) => (
            <Row key={m[0]} cells={[
              [<b key="n">{m[0]}</b>, '2fr'],
              [m[3], '1.5fr'],
              [`${m[1]}s (${Math.round(m[1] / 60)}分)`, '1fr', 'mono'],
              [`${m[2]} km/h`, '1fr', 'mono'],
              [<SpeedGraph key="g" width={200} height={50} progress={1} simple />, '2fr'],
              [<div key="b" style={{ display: 'flex', gap: 6 }}>
                <Btn primary>選択</Btn><Btn>詳細</Btn>
              </div>, '1fr'],
            ]} style={{ padding: '10px 14px', borderBottom: `1px dashed ${INK_MUTE}` }} />
          ))}
        </Box>
      </div>
    </Frame>
  );
}

function ModesB({ state }) {
  return (
    <Frame state={state || 'READY'} screen="走行モード · アップロード" activeNav="modes">
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, height: '100%' }}>
        <Box label="新規モードを追加" style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Input label="モード名" value="WLTP_Class3" width="100%" />
          <Input label="説明" value="国際標準 WLTP クラス3" width="100%" />
          <div>
            <div style={{ fontSize: 13, color: INK_SOFT, marginBottom: 6 }}>基準車速CSV (time_s, speed_kmh)</div>
            <Hatch width="100%" height={120} label="CSV をここにドロップ または クリックして選択" />
          </div>
          <Box label="バリデーション">
            <div style={{ fontSize: 13, lineHeight: 1.8 }}>
              <div>✓ ヘッダ確認 (time_s, speed_kmh)</div>
              <div>✓ 時刻 単調増加</div>
              <div>✓ 車速範囲 0–131.3 km/h</div>
              <div>✓ サンプル数 1801</div>
            </div>
          </Box>
          <div style={{ flex: 1 }} />
          <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
            <Btn>キャンセル</Btn>
            <Btn primary big>保存</Btn>
          </div>
        </Box>
        <Box label="プレビュー: WLTP_Class3" style={{ padding: 14 }}>
          <SpeedGraph width="100%" height={280} progress={1} />
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, marginTop: 12, fontSize: 13 }}>
            <div><div style={{ color: INK_SOFT }}>総時間</div><b style={{ fontFamily: 'monospace' }}>1800 s</b></div>
            <div><div style={{ color: INK_SOFT }}>最高車速</div><b style={{ fontFamily: 'monospace' }}>131.3 km/h</b></div>
            <div><div style={{ color: INK_SOFT }}>平均車速</div><b style={{ fontFamily: 'monospace' }}>46.5 km/h</b></div>
            <div><div style={{ color: INK_SOFT }}>停止比率</div><b style={{ fontFamily: 'monospace' }}>13.2 %</b></div>
          </div>
        </Box>
      </div>
    </Frame>
  );
}

function ModesC({ state }) {
  return (
    <Frame state={state || 'READY'} screen="走行モード · ギャラリー" activeNav="modes">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <H2 sub="サイクルをグラフで一覧。クリックで詳細・実行へ。">走行モード ギャラリー</H2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
          {['WLTP_Class3', 'NEDC', 'JC08', 'Custom_City_A', 'Highway_120', '+ 新規追加'].map((n, i) => (
            <Box key={n} thick={i === 0} dashed={i === 5}
              style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 6, minHeight: 200,
                justifyContent: i === 5 ? 'center' : 'flex-start',
                alignItems: i === 5 ? 'center' : 'stretch' }}>
              {i === 5 ? (
                <div style={{ fontSize: 22, color: INK_SOFT }}>＋<br/>CSVをドロップ</div>
              ) : (
                <>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                    <div style={{ fontSize: 16, fontWeight: 700 }}>{n}</div>
                    <div style={{ fontSize: 12, color: INK_SOFT, fontFamily: 'monospace' }}>{[1800, 1180, 1204, 600, 900][i]}s</div>
                  </div>
                  <SpeedGraph width="100%" height={110} progress={1} simple />
                  <div style={{ display: 'flex', gap: 6, marginTop: 4 }}>
                    <Btn primary>選択</Btn>
                    <Btn>編集</Btn>
                    <Btn ghost style={{ marginLeft: 'auto' }}>×</Btn>
                  </div>
                </>
              )}
            </Box>
          ))}
        </div>
      </div>
    </Frame>
  );
}

// ── Mode Create — 新規作成ページ
function ModeCreate({ state }) {
  return (
    <Frame state={state || 'READY'} screen="走行モード · 新規作成" activeNav="modes">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, height: '100%' }}>

        {/* ヘッダ */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Btn>← 一覧に戻る</Btn>
          <H2 sub="基準車速CSVをアップロードして新しい走行モードを登録します">走行モード · 新規作成</H2>
        </div>

        {/* 2カラム本体 */}
        <div style={{ display: 'grid', gridTemplateColumns: '340px 1fr', gap: 14, flex: 1, minHeight: 0 }}>

          {/* ── 左：入力フォーム ── */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>

            <Box label="基本情報" style={{ padding: 18 }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <Input label="モード名" value="" width="100%" />
                <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
                  <div style={{ fontSize: 13, color: INK_SOFT }}>説明</div>
                  <div style={{
                    width: '100%', padding: '7px 10px',
                    border: `1.3px solid ${INK}`, borderRadius: 3,
                    background: PAPER, fontSize: 15,
                    color: INK_MUTE, minHeight: 72,
                  }}>例: 国際標準 WLTP クラス3</div>
                </div>
              </div>
            </Box>

            <Box label="CSVファイル (time_s, speed_kmh)" style={{ padding: 18 }}>
              <div style={{
                border: `2px dashed ${INK}`,
                borderRadius: 4,
                background: PAPER_2,
                display: 'flex', flexDirection: 'column',
                alignItems: 'center', justifyContent: 'center',
                gap: 8, padding: '24px 12px',
                textAlign: 'center',
              }}>
                <div style={{ fontSize: 28, color: INK_MUTE }}>↑</div>
                <div style={{ fontSize: 15, fontWeight: 700 }}>ここにCSVをドロップ</div>
                <div style={{ fontSize: 13, color: INK_SOFT }}>または</div>
                <Btn>ファイルを選択</Btn>
                <div style={{ fontSize: 12, color: INK_MUTE, marginTop: 4, fontFamily: 'monospace' }}>
                  .csv / UTF-8 / ヘッダ行あり
                </div>
              </div>

              {/* バリデーション結果（アップロード後イメージ） */}
              <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 5 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: INK_SOFT, marginBottom: 2 }}>バリデーション</div>
                {[
                  ['✓', 'ヘッダ確認 (time_s, speed_kmh)', true],
                  ['✓', '時刻 単調増加', true],
                  ['✓', '車速範囲 0 – 131.3 km/h', true],
                  ['✓', 'サンプル数 1801 行', true],
                ].map(([icon, msg, ok]) => (
                  <div key={msg} style={{
                    fontSize: 13, fontFamily: 'monospace',
                    color: ok ? '#22421f' : '#5e1414',
                  }}>{icon} {msg}</div>
                ))}
              </div>
            </Box>

            <Note>CSVの1列目は秒単位の時刻、2列目は km/h の基準車速。ヘッダ行は必須です。</Note>

            <div style={{ flex: 1 }} />
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <Btn>キャンセル</Btn>
              <Btn primary big>保存</Btn>
            </div>
          </div>

          {/* ── 右：大プレビュー ── */}
          <Box label="プレビュー" style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 16 }}>

            {/* 大グラフ */}
            <div style={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ fontSize: 14, color: INK_SOFT }}>基準車速プロファイル</div>
              <SpeedGraph width="100%" height={320} progress={1} />
            </div>

            {/* 統計サマリ */}
            <div style={{
              display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12,
              borderTop: `1px dashed ${INK_MUTE}`, paddingTop: 14,
            }}>
              {[
                ['総時間', '1800 s (30分)'],
                ['最高車速', '131.3 km/h'],
                ['平均車速', '46.5 km/h'],
                ['停止比率', '13.2 %'],
              ].map(([label, val]) => (
                <div key={label} style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                  <div style={{ fontSize: 12, color: INK_SOFT }}>{label}</div>
                  <div style={{ fontSize: 18, fontWeight: 700, fontFamily: 'monospace' }}>{val}</div>
                </div>
              ))}
            </div>

            {/* CSVサンプル */}
            <Box label="CSVサンプル (先頭5行)" style={{ padding: 12 }}>
              <div style={{ fontFamily: 'monospace', fontSize: 13, lineHeight: 1.8, color: INK_SOFT }}>
                <div style={{ color: INK, fontWeight: 700 }}>time_s,speed_kmh</div>
                <div>0.0,0.0</div>
                <div>1.0,0.0</div>
                <div>2.0,2.1</div>
                <div>3.0,4.8</div>
                <div style={{ color: INK_MUTE }}>… (1796行省略)</div>
              </div>
            </Box>

          </Box>
        </div>
      </div>
    </Frame>
  );
}

Object.assign(window, { ProfilesA, ProfilesB, ProfilesC, ProfileForm, ProfileCreate, ProfileEdit, ModesA, ModesB, ModesC, ModeCreate });
