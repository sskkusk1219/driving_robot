// Manual / Learning / Logs / Init — supporting screens

// ── Manual operation — 3 variations
function ManualA({ state }) {
  return (
    <Frame state={state || 'RUNNING'} screen="手動操作 · スライダー" activeNav="manual">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, height: '100%' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <H2 sub="アクセル・ブレーキ開度をリアルタイムで指令します。走行前チェック通過済み。">手動操作</H2>
          <div style={{ flex: 1 }} />
          <Pill accent="RUNNING">MANUAL</Pill>
          <Btn danger big>■ 手動操作 終了</Btn>
        </div>
        <Box label="アクセル開度" style={{ padding: 18 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
            <Btn big>−10</Btn>
            <Btn big>−1</Btn>
            <div style={{ flex: 1, position: 'relative' }}>
              <div style={{ height: 28, border: `1.6px solid ${INK}`, position: 'relative', background: PAPER }}>
                <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: '42.3%', background: INK, opacity: 0.85 }} />
                <div style={{
                  position: 'absolute', left: '42.3%', top: -8, bottom: -8,
                  width: 18, marginLeft: -9,
                  background: PAPER, border: `2px solid ${INK}`, borderRadius: 3,
                }} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: INK_SOFT, marginTop: 4, fontFamily: 'monospace' }}>
                <span>0 %</span><span>50</span><span>100 % (max 80)</span>
              </div>
            </div>
            <Btn big>+1</Btn>
            <Btn big>+10</Btn>
            <Input label="" value="42.3" width={80} mono />
          </div>
          <div style={{ display: 'flex', gap: 18, fontSize: 13, color: INK_SOFT, marginTop: 8 }}>
            <span>現在位置 <b style={{ fontFamily: 'monospace', color: INK }}>2240 pulse</b></span>
            <span>電流 <b style={{ fontFamily: 'monospace', color: INK }}>684 mA</b></span>
            <span style={{ flex: 1 }} />
            <Btn>0 にリセット</Btn>
          </div>
        </Box>
        <Box label="ブレーキ開度" style={{ padding: 18 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
            <Btn big>−10</Btn>
            <Btn big>−1</Btn>
            <div style={{ flex: 1 }}>
              <div style={{ height: 28, border: `1.6px solid ${INK}`, position: 'relative', background: PAPER }}>
                <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: '0%', background: '#a23232', opacity: 0.85 }} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: INK_SOFT, marginTop: 4, fontFamily: 'monospace' }}>
                <span>0 %</span><span>50</span><span>100 % (max 70)</span>
              </div>
            </div>
            <Btn big>+1</Btn>
            <Btn big>+10</Btn>
            <Input label="" value="0.0" width={80} mono />
          </div>
        </Box>
        <Box label="現在のステータス" style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, padding: 14 }}>
          <div><div style={{ fontSize: 12, color: INK_SOFT }}>実車速</div><div style={{ fontSize: 28, fontFamily: 'monospace', fontWeight: 700 }}>0.0</div></div>
          <div><div style={{ fontSize: 12, color: INK_SOFT }}>セッション</div><div style={{ fontSize: 17, fontFamily: 'monospace' }}>#2484</div></div>
          <div><div style={{ fontSize: 12, color: INK_SOFT }}>経過</div><div style={{ fontSize: 17, fontFamily: 'monospace' }}>00:42</div></div>
          <div><div style={{ fontSize: 12, color: INK_SOFT }}>ログ書き込み</div><div style={{ fontSize: 17, fontFamily: 'monospace' }}>100ms ●</div></div>
        </Box>
      </div>
    </Frame>
  );
}

function ManualB({ state }) {
  return (
    <Frame state={state || 'RUNNING'} screen="手動操作 · ダイヤル" activeNav="manual">
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18, height: '100%' }}>
        {['アクセル', 'ブレーキ'].map((axis, i) => {
          const val = i === 0 ? 42.3 : 0;
          const color = i === 0 ? INK : '#a23232';
          // arc dial
          const cx = 140, cy = 140, r = 100;
          const a0 = -210, a1 = 30;
          const a = a0 + (a1 - a0) * (val / 100);
          const arcPath = (() => {
            const toXY = (ang) => [cx + Math.cos(ang * Math.PI / 180) * r, cy + Math.sin(ang * Math.PI / 180) * r];
            const [x1, y1] = toXY(a0), [x2, y2] = toXY(a);
            const large = (a - a0) > 180 ? 1 : 0;
            return `M ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2}`;
          })();
          return (
            <Box key={axis} label={axis} style={{ padding: 18, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14 }}>
              <svg viewBox="0 0 280 200" width="100%" height="200">
                <path d={`M ${cx + Math.cos(a0 * Math.PI / 180) * r} ${cy + Math.sin(a0 * Math.PI / 180) * r} A ${r} ${r} 0 1 1 ${cx + Math.cos(a1 * Math.PI / 180) * r} ${cy + Math.sin(a1 * Math.PI / 180) * r}`}
                  fill="none" stroke={INK_MUTE} strokeWidth="3" />
                <path d={arcPath} fill="none" stroke={color} strokeWidth="8" />
                <text x={cx} y={cy + 6} fontSize="46" fontWeight="800" textAnchor="middle" fontFamily="inherit">{val.toFixed(1)}</text>
                <text x={cx} y={cy + 30} fontSize="13" textAnchor="middle" fill={INK_SOFT}>%</text>
              </svg>
              <div style={{ display: 'flex', gap: 8 }}>
                <Btn big>−10</Btn>
                <Btn big>−1</Btn>
                <Btn big>+1</Btn>
                <Btn big>+10</Btn>
              </div>
              <Input value={val.toFixed(1)} width={140} mono />
              <div style={{ fontSize: 12, color: INK_SOFT, fontFamily: 'monospace' }}>max {i === 0 ? 80 : 70} % · {i === 0 ? 2240 : 0} pulse</div>
            </Box>
          );
        })}
      </div>
    </Frame>
  );
}

function ManualC({ state }) {
  return (
    <Frame state={state || 'RUNNING'} screen="手動操作 · プリセット併用" activeNav="manual">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, height: '100%' }}>
        <Box label="プリセット" style={{ padding: 12 }}>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {[
              ['アイドリング', 'acc 0 / brk 0'],
              ['アクセル 25%', 'acc 25'],
              ['アクセル 50%', 'acc 50'],
              ['アクセル 75%', 'acc 75'],
              ['ブレーキ 30%', 'brk 30'],
              ['ブレーキ 60%', 'brk 60'],
              ['緊急停止テスト', 'home'],
            ].map(([l, s], i) => (
              <Btn key={l} primary={i === 0} style={{ flexDirection: 'column', height: 'auto', padding: '8px 14px' }}>
                <div>{l}</div>
                <div style={{ fontSize: 11, color: INK_SOFT, fontFamily: 'monospace' }}>{s}</div>
              </Btn>
            ))}
          </div>
        </Box>
        <Box label="現在開度" style={{ padding: 18 }}>
          <PedalBar label="アクセル" value={42.3} width={500} />
          <div style={{ height: 14 }} />
          <PedalBar label="ブレーキ" value={0} width={500} color="#a23232" />
        </Box>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 14, flex: 1 }}>
          <Box label="実車速 / 電流 推移" style={{ padding: 10 }}>
            <Hatch width="100%" height={200} label="time-series: speed / current (sketch)" />
          </Box>
          <Box label="ステータス" style={{ padding: 14 }}>
            <Row cells={[['項目', '1fr'], ['値', '1fr']]} header />
            <Row cells={[['実車速', '1fr'], ['0.0 km/h', '1fr', 'mono']]} />
            <Row cells={[['アクセル pos', '1fr'], ['2240', '1fr', 'mono']]} />
            <Row cells={[['ブレーキ pos', '1fr'], ['0', '1fr', 'mono']]} />
            <Row cells={[['acc 電流', '1fr'], ['684 mA', '1fr', 'mono']]} />
            <Row cells={[['brk 電流', '1fr'], ['142 mA', '1fr', 'mono']]} />
            <div style={{ marginTop: 12 }}>
              <Btn danger big style={{ width: '100%' }}>■ 手動操作終了</Btn>
            </div>
          </Box>
        </div>
      </div>
    </Frame>
  );
}

// ── Learning drive — 3 variations
function LearningA({ state }) {
  return (
    <Frame state={state || 'RUNNING'} screen="学習運転 · 進捗" activeNav="learning">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, height: '100%' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <H2 sub="速度×加速度グリッドで自動走行しモデル学習用ログを取得">学習運転</H2>
          <div style={{ flex: 1 }} />
          <Pill accent="RUNNING">RUNNING · pattern 18 / 48</Pill>
          <Btn danger big>■ 中止</Btn>
        </div>
        <Box label="走行パターン グリッド (速度 × 加速度)" style={{ padding: 14 }}>
          <svg viewBox="0 0 600 220" width="100%" height="220">
            {Array.from({ length: 8 }, (_, x) =>
              Array.from({ length: 6 }, (_, y) => {
                const idx = y * 8 + x;
                let fill = PAPER;
                if (idx < 18) fill = '#dde6f0';     // done
                else if (idx === 18) fill = '#a23232'; // running
                else if (idx > 40) fill = '#f1efe9'; // skipped
                return (
                  <g key={idx}>
                    <rect x={20 + x * 70} y={10 + y * 32} width="64" height="28"
                      fill={fill} stroke={INK} strokeWidth="1" />
                    {idx === 18 && <text x={52 + x * 70} y={30 + y * 32} fontSize="10" textAnchor="middle" fill="#fff" fontWeight="700">●</text>}
                    {idx > 40 && <text x={52 + x * 70} y={30 + y * 32} fontSize="11" textAnchor="middle" fill={INK_MUTE}>skip</text>}
                  </g>
                );
              })
            )}
            <text x="14" y="14" fontSize="10" fontFamily="monospace" fill={INK_SOFT}>accel↑</text>
            <text x="580" y="218" fontSize="10" fontFamily="monospace" fill={INK_SOFT} textAnchor="end">→ speed</text>
          </svg>
          <div style={{ display: 'flex', gap: 14, fontSize: 12, color: INK_SOFT, marginTop: 6 }}>
            <span><span style={{ display: 'inline-block', width: 14, height: 10, background: '#dde6f0', border: `1px solid ${INK}` }} /> 完了 (18)</span>
            <span><span style={{ display: 'inline-block', width: 14, height: 10, background: '#a23232', border: `1px solid ${INK}` }} /> 走行中 (1)</span>
            <span><span style={{ display: 'inline-block', width: 14, height: 10, background: PAPER, border: `1px solid ${INK}` }} /> 待機 (22)</span>
            <span><span style={{ display: 'inline-block', width: 14, height: 10, background: '#f1efe9', border: `1px solid ${INK}` }} /> スキップ — 最大開度・G上限超 (7)</span>
          </div>
        </Box>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 14, flex: 1 }}>
          <Box label="現在パターン: speed 60 km/h × accel +2.0 km/h/s" style={{ padding: 10 }}>
            <SpeedGraph width="100%" height={200} progress={0.42} />
          </Box>
          <Box label="進捗" style={{ padding: 14 }}>
            <TimeProgress elapsed={520} total={1200} />
            <div style={{ height: 12 }} />
            <Row cells={[['ログサンプル数', '1fr'], ['62,400', '1fr', 'mono']]} />
            <Row cells={[['ファイルサイズ', '1fr'], ['~5.8 MB', '1fr', 'mono']]} />
            <Row cells={[['推定完了', '1fr'], ['13:58', '1fr', 'mono']]} />
            <div style={{ marginTop: 10 }}>
              <Btn primary big style={{ width: '100%' }}>学習完了後にモデル学習を実行 ☑</Btn>
            </div>
          </Box>
        </div>
      </div>
    </Frame>
  );
}

function LearningB({ state }) {
  return (
    <Frame state={state || 'READY'} screen="学習運転 · 開始前" activeNav="learning">
      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 14, height: '100%' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <H2 sub="プロファイル「Prius_2024」の運転モデルを学習します">学習運転</H2>
          <Box label="生成された走行パターン">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, fontSize: 14 }}>
              <div>速度グリッド: <b style={{ fontFamily: 'monospace' }}>0–120 km/h, step 15</b></div>
              <div>加速度グリッド: <b style={{ fontFamily: 'monospace' }}>−3 to +3, step 1</b></div>
              <div>パターン総数: <b style={{ fontFamily: 'monospace' }}>48</b></div>
              <div>うちスキップ: <b style={{ fontFamily: 'monospace' }}>7 (G上限超)</b></div>
              <div>推定所要時間: <b style={{ fontFamily: 'monospace' }}>~18 分</b></div>
              <div>ログ容量: <b style={{ fontFamily: 'monospace' }}>~14 MB</b></div>
            </div>
          </Box>
          <Box label="走行前チェック">
            {[
              'ttyUSB0/1, CAN 通信 OK',
              'サーボ ON, アラームなし',
              'キャリブレーション 有効',
              'プロファイル選択済み',
              'UPS残量 87% (>20%)',
              'アクチュエータ原点付近',
            ].map(c => (
              <div key={c} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0', fontSize: 14 }}>
                <span style={{ color: '#3f6b3f', fontWeight: 700 }}>✓</span> {c}
              </div>
            ))}
          </Box>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
            <Btn>パターン設定を変更</Btn>
            <Btn primary big>▶ 学習運転を開始</Btn>
          </div>
        </div>
        <Box label="パターン分布プレビュー">
          <Hatch width="100%" height={280} label="speed × accel grid (skipped cells shown)" />
          <div style={{ fontSize: 13, color: INK_SOFT, marginTop: 10, lineHeight: 1.7 }}>
            最大開度 (80%/70%) または最大減速G (0.6G) を超えるパターンは自動でスキップされます。
            完了後、ログから FF モデル (.pkl) を学習・プロファイルに保存します。
          </div>
        </Box>
      </div>
    </Frame>
  );
}

function LearningC({ state }) {
  return (
    <Frame state={state || 'READY'} screen="学習運転 · モデル学習結果" activeNav="learning">
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, height: '100%' }}>
        <Box label="学習済みモデル: Prius_2024 / driving_model.pkl" style={{ padding: 14 }}>
          <Hatch width="100%" height={300} label="2D heatmap — accel opening as function of (speed, accel)" />
          <div style={{ fontSize: 13, color: INK_SOFT, marginTop: 8 }}>学習日: 2026-05-08 14:42 · 学習ログ 41パターン · 補間: 線形</div>
        </Box>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Box label="検証">
            <Row cells={[['指標', '2fr'], ['結果', '1fr', 'mono']]} header />
            <Row cells={[['予測誤差 (95%tile)', '2fr'], ['±0.14 km/h', '1fr', 'mono']]} />
            <Row cells={[['最大予測誤差', '2fr'], ['0.62 km/h', '1fr', 'mono']]} />
            <Row cells={[['学習データ数', '2fr'], ['41 patterns', '1fr', 'mono']]} />
            <Row cells={[['再学習可否', '2fr'], ['可能', '1fr', 'mono']]} />
          </Box>
          <Box label="モデル履歴">
            <Row cells={[['日時', '1.5fr', 'mono'], ['ログ数', '1fr', 'mono'], ['誤差95%', '1fr', 'mono'], ['', '1fr']]} header />
            <Row cells={[['2026-05-08 14:42', '1.5fr', 'mono'], ['41', '1fr', 'mono'], ['0.14', '1fr', 'mono'], [<Pill key="a" accent="READY">使用中</Pill>, '1fr']]} />
            <Row cells={[['2026-04-22 10:15', '1.5fr', 'mono'], ['38', '1fr', 'mono'], ['0.21', '1fr', 'mono'], [<Btn key="b">復元</Btn>, '1fr']]} />
            <Row cells={[['2026-03-30 17:02', '1.5fr', 'mono'], ['35', '1fr', 'mono'], ['0.33', '1fr', 'mono'], [<Btn key="c">復元</Btn>, '1fr']]} />
          </Box>
          <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
            <Btn>過去ログから再学習</Btn>
            <Btn primary>新規 学習運転 →</Btn>
          </div>
        </div>
      </div>
    </Frame>
  );
}

// ── Manual Jog — ジョグ操作でアクチュエータを直接制御
function ManualJog({ state }) {
  const [confirmStop, setConfirmStop] = React.useState(false);
  const AxisJog = ({ axis, color, current, zero, full, current_pct, max_pct, current_mA }) => (
    <Box label={axis} style={{ padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: 10 }}>
      {/* 位置ルーラー */}
      <PosRuler current={current} zero={zero} full={full} width={460} />

      {/* ジョグボタン + 現在位置 */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <JogKey label="−10" sub="Shift+←" big />
        <JogKey label="−1"  sub="←"       big />
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1 }}>
          <div style={{ fontSize: 12, color: INK_SOFT }}>現在位置</div>
          <div style={{ fontSize: 32, fontFamily: 'monospace', fontWeight: 800, lineHeight: 1 }}>{current}</div>
          <div style={{ fontSize: 11, color: INK_SOFT }}>pulse</div>
        </div>
        <JogKey label="+1"  sub="→"       big />
        <JogKey label="+10" sub="Shift+→" big />
      </div>

      {/* 開度バー */}
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: INK_SOFT, marginBottom: 3, fontFamily: 'monospace' }}>
          <span>0 %</span><span>50</span><span>100 % (max {max_pct})</span>
        </div>
        <div style={{ height: 14, border: `1.4px solid ${INK}`, position: 'relative', background: PAPER }}>
          <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: `${current_pct}%`, background: color, opacity: 0.82 }} />
        </div>
      </div>

      {/* サブ情報 */}
      <div style={{ display: 'flex', gap: 14, fontSize: 13, color: INK_SOFT, alignItems: 'center' }}>
        <span>開度 <b style={{ fontFamily: 'monospace', color: INK }}>{current_pct.toFixed(1)} %</b></span>
        <span>電流 <b style={{ fontFamily: 'monospace', color: INK }}>{current_mA} mA</b></span>
        <div style={{ flex: 1 }} />
        <Btn>原点へ戻す</Btn>
      </div>
    </Box>
  );

  return (
    <div style={{ position: 'relative', width: '100%', height: '100%' }}>
      <Frame state={state || 'READY'} screen="手動運転" activeNav="manual">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, height: '100%' }}>

        {/* ヘッダ */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <H2 sub=""></H2>
          <div style={{ flex: 1 }} />
          <Pill accent={state || 'READY'}>MANUAL</Pill>
        </div>

        {/* 2軸 + 下段を1つのグリッドにまとめて列を完全に揃える */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gridTemplateRows: '1fr auto',
          gap: 10,
          flex: 1,
          minHeight: 0,
        }}>
          {/* 上段左: ブレーキ */}
          <AxisJog
            axis="ブレーキ" color={INK}
            current={2240} zero={820} full={4180}
            current_pct={42.3} max_pct={80} current_mA={684}
          />
          {/* 上段右: アクセル */}
          <AxisJog
            axis="アクセル" color="#a23232"
            current={650} zero={650} full={3920}
            current_pct={0.0} max_pct={70} current_mA={142}
          />

          {/* 下段左: キーボードショートカット */}
          <Box label="キーボードショートカット" style={{ padding: 12 }}>
            <div style={{ fontSize: 13, lineHeight: 1.9, fontFamily: 'monospace' }}>
              <div>← / →        : ±1 pulse</div>
              <div>Shift+← / →  : ±10 pulse</div>
              <div>Tab           : 軸切替 (アクセル ↔ ブレーキ)</div>
              <div>Esc           : 手動運転終了</div>
            </div>
            <Note style={{ marginTop: 8 }}>ジョグ中は最大開度リミットが有効です。電流値を常時監視中。</Note>
          </Box>

          {/* 下段右: ステータス＋停止ボタン（AutoDriveD の走行停止と同位置） */}
          <div style={{ display: 'flex', gap: 10, alignItems: 'stretch' }}>
            <Box style={{ padding: '10px 14px', fontSize: 13, flex: 1 }}>
              <Row cells={[['実車速',       '1.4fr'], ['0.0 km/h',   '1fr', 'mono']]} />
              <Row cells={[['ブレーキ pos', '1.4fr'], ['2240 pulse', '1fr', 'mono']]} />
              <Row cells={[['アクセル pos', '1.4fr'], ['650 pulse',  '1fr', 'mono']]} />
            </Box>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, flex: 1 }}>
              <Btn danger big style={{ flex: 1 }} onClick={() => setConfirmStop(true)}>■ 運転終了</Btn>
            </div>
          </div>
        </div>

      </div>
    </Frame>
    {confirmStop && (
      <ConfirmStopPopup
        message="運転を終了しますか？"
        onYes={() => setConfirmStop(false)}
        onNo={() => setConfirmStop(false)}
      />
    )}
    </div>
  );
}

// ── Manual operation — ⑥と同じUIレイアウト、サイドバーのみ「manual」をハイライト
function ManualNew({ state }) {
  return <AutoDriveD state={state} activeNav="manual" screen="手動操作" />;
}

// ── Learning drive — ⑥と同じUIレイアウト、サイドバーのみ「learning」をハイライト
function LearningNew({ state }) {
  return <AutoDriveD state={state} activeNav="learning" screen="学習運転" showPause={false} />;
}
function LogsA({ state }) {
  const [detailIdx, setDetailIdx] = React.useState(null);
  const sessions = [
    ['2026-05-12 13:42', 'auto', 'WLTP_Class3', 'Prius_2024', 'completed', 1801, '0.14'],
    ['2026-05-12 11:08', 'auto', 'NEDC', 'Prius_2024', 'completed', 1181, '0.18'],
    ['2026-05-12 09:50', 'manual', '—', 'Prius_2024', 'completed', 312, '—'],
    ['2026-05-11 16:20', 'learning', 'pattern_grid', 'Prius_2024', 'completed', 1085, '—'],
    ['2026-05-11 14:02', 'auto', 'WLTP_Class3', 'Prius_2024', 'emergency', 612, '1.92'],
    ['2026-05-11 10:11', 'auto', 'JC08', 'Corolla_Hybrid', 'completed', 1205, '0.12'],
  ];

  if (detailIdx !== null) {
    const s = sessions[detailIdx];
    return (
      <Frame state={state || 'READY'} screen="ログ · 詳細グラフ" activeNav="logs">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14, height: '100%' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <Btn onClick={() => setDetailIdx(null)}>← 一覧に戻る</Btn>
            <H2 sub={`${s[0]} · ${s[2]} · ${s[3]} · ${s[5]}s · 結果: ${s[4]}`}>セッション #{2483 + detailIdx} 詳細</H2>
            <div style={{ flex: 1 }} />
            <Btn>CSV ダウンロード</Btn>
            <Btn>このログでモデル再学習</Btn>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10 }}>
            {[['偏差P95', `${s[6]} km/h`], ['最大偏差', '0.62'], ['逸脱発生', '0回'], ['平均アクセル', '32.4%'], ['平均ブレーキ', '4.1%']].map(([l, v]) => (
              <Box key={l} style={{ padding: '8px 10px', textAlign: 'center' }}>
                <div style={{ fontSize: 12, color: INK_SOFT }}>{l}</div>
                <div style={{ fontSize: 22, fontFamily: 'monospace', fontWeight: 700 }}>{v}</div>
              </Box>
            ))}
          </div>
          <Box label="基準 vs 実車速 (全期間)" style={{ padding: 10 }}>
            <SpeedGraph width="100%" height={220} progress={1} />
          </Box>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, flex: 1 }}>
            <Box label="アクセル開度 / 電流" style={{ padding: 10 }}>
              <Hatch width="100%" height={170} label="accel opening (%) + current (mA) over time" />
            </Box>
            <Box label="ブレーキ開度 / 電流" style={{ padding: 10 }}>
              <Hatch width="100%" height={170} label="brake opening (%) + current (mA) over time" />
            </Box>
          </div>
        </div>
      </Frame>
    );
  }

  return (
    <Frame state={state || 'READY'} screen="ログ · 一覧" activeNav="logs">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, height: '100%' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <H2 sub="過去3ヶ月分のセッション。容量超過時はUSB SSDに圧縮アーカイブ。">走行ログ</H2>
          <div style={{ flex: 1 }} />
          <Input label="" value="🔍 セッション検索..." width={220} />
          <Btn>絞り込み</Btn>
          <Btn>CSV 一括DL</Btn>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          {['全て', 'auto', 'manual', 'learning', 'emergency'].map((t, i) => (
            <Btn key={t} primary={i === 0}>{t}</Btn>
          ))}
          <div style={{ flex: 1 }} />
          <span style={{ fontSize: 13, color: INK_SOFT }}>内蔵SSD: <b style={{ fontFamily: 'monospace' }}>42%</b> · USB SSD: <b style={{ fontFamily: 'monospace' }}>61%</b></span>
        </div>
        <Box style={{ padding: 0 }}>
          <Row cells={[
            ['日時', '1.5fr', 'mono'], ['種類', '0.8fr'], ['モード', '1.4fr'],
            ['プロファイル', '1.4fr'], ['結果', '1fr'], ['長さ', '0.8fr', 'mono'],
            ['偏差P95', '0.8fr', 'mono'], ['操作', '1fr'],
          ]} header style={{ padding: '10px 14px', background: PAPER_2 }} />
          {sessions.map((s, i) => (
            <Row key={i} cells={[
              [s[0], '1.5fr', 'mono'],
              [<Pill key="p">{s[1]}</Pill>, '0.8fr'],
              [s[2], '1.4fr'],
              [s[3], '1.4fr'],
              [s[4] === 'emergency' ? <Pill key="x" accent="EMERGENCY">{s[4]}</Pill> : <Pill key="x" accent="READY">{s[4]}</Pill>, '1fr'],
              [`${s[5]}s`, '0.8fr', 'mono'],
              [s[6], '0.8fr', 'mono'],
              [<div key="b" style={{ display: 'flex', gap: 6 }}>
                <Btn onClick={() => setDetailIdx(i)}>詳細</Btn><Btn>CSV</Btn>
              </div>, '1fr'],
            ]} style={{ padding: '10px 14px', borderBottom: `1px dashed ${INK_MUTE}` }} />
          ))}
        </Box>
      </div>
    </Frame>
  );
}

function LogsB({ state }) {
  return (
    <Frame state={state || 'READY'} screen="ログ · 詳細グラフ" activeNav="logs">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, height: '100%' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Btn>← 一覧に戻る</Btn>
          <H2 sub="2026-05-12 13:42 · WLTP_Class3 · Prius_2024 · 1801s · 結果: 正常完了">セッション #2483 詳細</H2>
          <div style={{ flex: 1 }} />
          <Btn>CSV ダウンロード</Btn>
          <Btn>このログでモデル再学習</Btn>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10 }}>
          {[['偏差P95', '0.14 km/h'], ['最大偏差', '0.62'], ['逸脱発生', '0回'], ['平均アクセル', '32.4%'], ['平均ブレーキ', '4.1%']].map(([l, v]) => (
            <Box key={l} style={{ padding: '8px 10px', textAlign: 'center' }}>
              <div style={{ fontSize: 12, color: INK_SOFT }}>{l}</div>
              <div style={{ fontSize: 22, fontFamily: 'monospace', fontWeight: 700 }}>{v}</div>
            </Box>
          ))}
        </div>
        <Box label="基準 vs 実車速 (全期間)" style={{ padding: 10 }}>
          <SpeedGraph width="100%" height={220} progress={1} />
        </Box>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, flex: 1 }}>
          <Box label="アクセル開度 / 電流" style={{ padding: 10 }}>
            <Hatch width="100%" height={170} label="accel opening (%) + current (mA) over time" />
          </Box>
          <Box label="ブレーキ開度 / 電流" style={{ padding: 10 }}>
            <Hatch width="100%" height={170} label="brake opening (%) + current (mA) over time" />
          </Box>
        </div>
      </div>
    </Frame>
  );
}

function LogsC({ state }) {
  return (
    <Frame state={state || 'READY'} screen="ログ · ストレージ管理" activeNav="logs">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, height: '100%' }}>
        <H2 sub="3ヶ月超のログは80%超で自動アーカイブされます。">ログ ストレージ</H2>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          {[
            ['内蔵SSD (PostgreSQL)', 42, '8.4 / 20 GB', '3ヶ月内アクティブ'],
            ['外付け USB SSD (アーカイブ)', 61, '610 / 1000 GB', '3ヶ月超 CSV+gzip'],
          ].map(([l, pct, vol, sub]) => (
            <Box key={l} label={l} style={{ padding: 14 }}>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
                <div style={{ fontSize: 38, fontFamily: 'monospace', fontWeight: 700 }}>{pct}<span style={{ fontSize: 18, color: INK_SOFT }}>%</span></div>
                <div style={{ fontSize: 13, color: INK_SOFT, fontFamily: 'monospace' }}>{vol}</div>
              </div>
              <div style={{ height: 16, border: `1.4px solid ${INK}`, position: 'relative', marginTop: 6 }}>
                <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: `${pct}%`, background: pct > 80 ? '#a23232' : '#2f5780', opacity: 0.7 }} />
                <div style={{ position: 'absolute', left: '80%', top: -3, bottom: -3, width: 0, borderLeft: `2px dashed #a23232` }} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: INK_SOFT, marginTop: 4 }}>
                <span>0</span><span style={{ color: '#a23232' }}>80% (trigger)</span><span>100</span>
              </div>
              <div style={{ fontSize: 13, color: INK_SOFT, marginTop: 8 }}>{sub}</div>
            </Box>
          ))}
        </div>
        <Box label="アーカイブ履歴 (最新)" style={{ padding: 0 }}>
          <Row cells={[['日時', '1.5fr', 'mono'], ['対象期間', '2fr'], ['ファイル数', '1fr', 'mono'], ['圧縮後', '1fr', 'mono'], ['', '1fr']]} header style={{ padding: '8px 14px', background: PAPER_2 }} />
          {[
            ['2026-04-08 03:12', '2026-01-01 ~ 2026-01-12', 132, '2.1 GB'],
            ['2026-03-15 03:08', '2025-12-15 ~ 2025-12-31', 198, '3.4 GB'],
            ['2026-02-28 03:05', '2025-11-25 ~ 2025-12-14', 174, '2.8 GB'],
          ].map(r => (
            <Row key={r[0]} cells={[
              [r[0], '1.5fr', 'mono'], [r[1], '2fr'], [r[2], '1fr', 'mono'], [r[3], '1fr', 'mono'],
              [<Btn key="b">ダウンロード</Btn>, '1fr'],
            ]} style={{ padding: '10px 14px', borderBottom: `1px dashed ${INK_MUTE}` }} />
          ))}
        </Box>
      </div>
    </Frame>
  );
}

// ── Init / Pre-check — 2 variations
function InitA({ state }) {
  return (
    <Frame state="STANDBY" screen="初期化シーケンス" activeNav="init">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 18, height: '100%', maxWidth: 760, margin: '0 auto', justifyContent: 'center' }}>
        <H2 sub="アラームリセット → サーボON → 原点復帰 (必要時)">初期化を実行します</H2>
        <Box style={{ padding: 18 }}>
          {[
            ['通信確認 (ttyUSB0)', true, 'pymodbus connect OK'],
            ['通信確認 (ttyUSB1)', true, 'pymodbus connect OK'],
            ['通信確認 (CAN/Kvaser)', true, '/dev/usbcanII0 ready'],
            ['アラームリセット (両軸)', true, 'FC05 0x0407 → FF00'],
            ['サーボON (両軸)', 'now', '実行中... FC05 0x0403'],
            ['原点復帰', null, '前回正常終了 → スキップ予定'],
          ].map(([l, st, sub]) => (
            <div key={l} style={{
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '10px 4px', borderBottom: `1px dashed ${INK_MUTE}`,
            }}>
              <div style={{
                width: 26, height: 26, borderRadius: '50%',
                border: `1.4px solid ${st === true ? '#3f6b3f' : st === 'now' ? INK : INK_MUTE}`,
                background: st === true ? '#dfeadc' : st === 'now' ? PAPER_2 : 'transparent',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontWeight: 700, fontSize: 14,
              }}>{st === true ? '✓' : st === 'now' ? '⟳' : '—'}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 16, fontWeight: st === 'now' ? 700 : 400 }}>{l}</div>
                <div style={{ fontSize: 12, color: INK_SOFT, fontFamily: 'monospace' }}>{sub}</div>
              </div>
              {st === 'now' && <div style={{ fontSize: 13, color: INK_SOFT }}>実行中...</div>}
            </div>
          ))}
        </Box>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 12 }}>
          <Btn>キャンセル</Btn>
          <Btn primary big disabled>READY 待ち...</Btn>
        </div>
      </div>
    </Frame>
  );
}

function InitB({ state }) {
  return (
    <Frame state="EMERGENCY" screen="非常停止 / リセット" activeNav="init">
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 24, height: '100%' }}>
        <div style={{
          border: `3px solid #a23232`, background: '#f1d8d2',
          padding: '24px 40px', borderRadius: 8,
          textAlign: 'center', transform: 'rotate(-0.6deg)',
          boxShadow: '4px 4px 0 rgba(0,0,0,0.15)',
        }}>
          <div style={{ fontSize: 38, fontWeight: 800, color: '#5e1414', letterSpacing: 1 }}>EMERGENCY</div>
          <div style={{ fontSize: 16, color: '#5e1414', marginTop: 4 }}>非常停止スイッチ (操作エリア) が押されました</div>
        </div>
        <Box style={{ width: 600, padding: 18 }}>
          <H2 sub="セッション #2483 / 13:54:46 / 経過 760s で停止">停止シーケンスの記録</H2>
          {[
            ['GPIO割り込み検知', true, '13:54:46.012  GPIO17 RISING'],
            ['制御ループ停止', true, '13:54:46.014'],
            ['原点復帰 (両軸 asyncio.gather)', true, '13:54:46.180  HEND=1'],
            ['セッション終了 (status=emergency)', true, '13:54:46.220  PostgreSQL'],
            ['ログフラッシュ', true, '13:54:46.245'],
          ].map(([l, ok, ts]) => (
            <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '6px 0', fontSize: 14 }}>
              <span style={{ color: '#3f6b3f', fontWeight: 700 }}>✓</span>
              <span style={{ flex: 1 }}>{l}</span>
              <span style={{ fontSize: 11, fontFamily: 'monospace', color: INK_SOFT }}>{ts}</span>
            </div>
          ))}
        </Box>
        <div style={{ display: 'flex', gap: 14 }}>
          <Btn big>ログを確認</Btn>
          <Btn primary big style={{ padding: '14px 30px' }}>EMERGENCY をリセット → READY へ</Btn>
        </div>
      </div>
    </Frame>
  );
}

Object.assign(window, {
  ManualA, ManualB, ManualC,
  ManualNew, ManualJog,
  LearningA, LearningB, LearningC,
  LearningNew,
  LogsA, LogsB, LogsC,
  InitA, InitB,
});
