// Missing feature screens
// モデル学習進捗 / キャリブレーション失敗 / ログ再学習 / タイムスケジュール / シーケンス

// ── モデル学習 実行中の進捗画面
function ModelTrainingScreen() {
  const elapsed = 38; // seconds
  const phases = [
    ['学習ログ読み込み',           'done', '41 patterns · 62,400 records'],
    ['速度×加速度グリッド構築',   'done', '9×7 grid (63 cells)'],
    ['線形補間モデル生成 (scipy)', 'now',  'RegularGridInterpolator 実行中...'],
    ['モデル検証 (交差検証)',      'wait', '—'],
    ['.pkl 保存 → プロファイル更新', 'wait', '—'],
  ];

  return (
    <Frame state="RUNNING" screen="運転モデル学習 — 実行中" activeNav="learning">
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', gap: 22 }}>

        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 30, fontWeight: 800 }}>運転モデルを学習しています</div>
          <div style={{ fontSize: 16, color: INK_SOFT, marginTop: 4 }}>
            プロファイル: Prius_2024 · ログ: 2026-05-12 学習運転 (41パターン)
          </div>
        </div>

        <Box style={{ width: 620, padding: '20px 24px' }} label="学習フェーズ">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {phases.map(([label, st, sub]) => {
              const iconColor = st === 'done' ? '#3f6b3f' : st === 'now' ? '#2f5780' : INK_MUTE;
              const icon = st === 'done' ? '✓' : st === 'now' ? '⟳' : '—';
              return (
                <div key={label} style={{
                  display: 'flex', alignItems: 'center', gap: 12,
                  padding: '8px 10px',
                  background: st === 'now' ? '#dde6f0' : 'transparent',
                  border: st === 'now' ? `1.5px solid #2f5780` : '1px solid transparent',
                  borderRadius: 4,
                }}>
                  <div style={{
                    width: 26, height: 26, borderRadius: '50%',
                    border: `1.4px solid ${iconColor}`,
                    background: st === 'done' ? '#dfeadc' : st === 'now' ? '#dde6f0' : 'transparent',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 13, fontWeight: 700, color: iconColor, flexShrink: 0,
                  }}>{icon}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 15, fontWeight: st === 'now' ? 700 : 400, color: st === 'wait' ? INK_MUTE : INK }}>{label}</div>
                    <div style={{ fontSize: 12, fontFamily: 'monospace', color: INK_SOFT }}>{sub}</div>
                  </div>
                  {st === 'now' && <div style={{ fontSize: 13, color: '#2f5780', fontStyle: 'italic' }}>処理中...</div>}
                </div>
              );
            })}
          </div>

          <div style={{ marginTop: 16 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: INK_SOFT, marginBottom: 4, fontFamily: 'monospace' }}>
              <span>経過: {elapsed}s</span>
              <span>推定残り: ~15s</span>
            </div>
            <div style={{ height: 12, border: `1.4px solid ${INK}`, position: 'relative', background: PAPER }}>
              <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: '60%', background: '#2f5780', opacity: 0.7 }} />
            </div>
          </div>
        </Box>

        <Note style={{ width: 620 }}>
          学習完了後、モデルは data/models/Prius_2024/driving_model.pkl に保存され、プロファイルに自動紐づけされます。
        </Note>
      </div>
    </Frame>
  );
}

// ── モデル学習 完了画面
function ModelTrainingDoneScreen() {
  return (
    <Frame state="READY" screen="運転モデル学習 — 完了" activeNav="learning">
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', gap: 22 }}>
        <div style={{
          border: '2px solid #3f6b3f', background: '#dfeadc',
          padding: '22px 40px', borderRadius: 8, textAlign: 'center',
          transform: 'rotate(-0.3deg)',
        }}>
          <div style={{ fontSize: 38, color: '#3f6b3f', marginBottom: 6 }}>✓</div>
          <div style={{ fontSize: 28, fontWeight: 800, color: '#22421f' }}>モデル学習が完了しました</div>
          <div style={{ fontSize: 16, color: '#3f6b3f', marginTop: 6 }}>Prius_2024 / driving_model.pkl を更新しました</div>
        </div>

        <Box style={{ width: 620, padding: '16px 20px' }} label="学習結果">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
            {[
              ['学習パターン数', '41 / 48'],
              ['スキップ (G超過)', '7'],
              ['予測誤差 P95', '±0.14 km/h'],
              ['最大予測誤差', '0.62 km/h'],
              ['グリッドサイズ', '9 × 7 cells'],
              ['処理時間', '53s'],
            ].map(([l, v]) => (
              <div key={l} style={{ fontSize: 14 }}>
                <div style={{ color: INK_SOFT }}>{l}</div>
                <div style={{ fontFamily: 'monospace', fontWeight: 700 }}>{v}</div>
              </div>
            ))}
          </div>
          <Box label="保存先" style={{ padding: '8px 12px' }}>
            <div style={{ fontFamily: 'monospace', fontSize: 13, color: INK_SOFT }}>
              data/models/Prius_2024/driving_model.pkl
            </div>
          </Box>
        </Box>

        <div style={{ display: 'flex', gap: 12 }}>
          <Btn>モデル詳細を確認</Btn>
          <Btn primary big>▶ 自動走行を開始</Btn>
        </div>
      </div>
    </Frame>
  );
}

// ── キャリブレーション バリデーション失敗画面
function CalibrationErrorScreen() {
  const errors = [
    { axis: 'アクセル', field: 'ストローク', value: '180 pulse', expected: '2,000〜5,000 pulse', ng: true },
    { axis: 'ブレーキ', field: 'ZERO < FULL', value: 'ZERO=4,200 / FULL=800', expected: 'ZERO < FULL であること', ng: true },
  ];

  return (
    <Frame state="READY" screen="キャリブレーション — バリデーション失敗" activeNav="calibration">
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', gap: 20 }}>

        <div style={{
          border: '2.5px solid #a23232', background: '#f1d8d2',
          padding: '20px 36px', borderRadius: 8, textAlign: 'center',
          transform: 'rotate(-0.4deg)', width: 640,
        }}>
          <div style={{ fontSize: 28, fontWeight: 800, color: '#5e1414' }}>キャリブレーション失敗</div>
          <div style={{ fontSize: 16, color: '#8a3030', marginTop: 6 }}>
            バリデーションエラーが検出されました。設定を保存せずに停止しました。
          </div>
        </div>

        <Box style={{ width: 640, padding: '18px 20px' }} label="バリデーション結果">
          {errors.map(({ axis, field, value, expected }) => (
            <div key={`${axis}-${field}`} style={{
              marginBottom: 14, padding: '12px 14px',
              border: '1.5px solid #a23232', background: '#fdf0ee', borderRadius: 4,
            }}>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 6 }}>
                <div style={{ fontSize: 16, color: '#a23232', fontWeight: 700 }}>✗</div>
                <div style={{ fontSize: 16, fontWeight: 700, color: '#5e1414' }}>{axis} — {field}</div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, fontSize: 13, paddingLeft: 24 }}>
                <div>
                  <div style={{ color: INK_SOFT }}>実測値</div>
                  <div style={{ fontFamily: 'monospace', color: '#a23232', fontWeight: 700 }}>{value}</div>
                </div>
                <div>
                  <div style={{ color: INK_SOFT }}>期待値</div>
                  <div style={{ fontFamily: 'monospace' }}>{expected}</div>
                </div>
              </div>
            </div>
          ))}
        </Box>

        <Box style={{ width: 640, padding: '14px 18px' }} label="解決方法">
          <div style={{ fontSize: 14, lineHeight: 1.9, color: INK_SOFT }}>
            <div>• <b style={{ color: INK }}>ストロークが小さすぎる場合</b>: ジョグ操作でペダルを正しい最大踏み込み位置まで動かしてから FULL を記録してください</div>
            <div>• <b style={{ color: INK }}>ZERO &gt; FULL の場合</b>: アクチュエータのロッド方向を確認し、ZERO (接触点) と FULL (最大踏み込み) の順序が正しいか確認してください</div>
            <div>• キャリブレーション中は最大開度設定が無視されます — 全ストロークで設定できます</div>
          </div>
        </Box>

        <div style={{ display: 'flex', gap: 12 }}>
          <Btn>キャンセル</Btn>
          <Btn primary big>⟳ キャリブレーションをやり直す</Btn>
        </div>
      </div>
    </Frame>
  );
}

// ── ログからモデル再学習フロー (2画面)
function RetrainSelectLogScreen() {
  const sessions = [
    ['2026-05-12 13:42', 'learning', '41 patterns', '62,400 records', true],
    ['2026-04-22 10:08', 'learning', '38 patterns', '57,600 records', false],
    ['2026-03-30 16:55', 'learning', '35 patterns', '52,800 records', false],
    ['2026-05-12 11:08', 'auto',     'WLTP_Class3', '18,010 records', false],
  ];

  return (
    <Frame state="READY" screen="ログからモデル再学習 — ログ選択" activeNav="learning">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, height: '100%' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Btn>← 戻る</Btn>
          <H2 sub="使用する学習ログを選択してモデルを再学習します">ログからモデル再学習 — Prius_2024</H2>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 14, flex: 1 }}>
          <Box label="学習ログ / 走行ログを選択" style={{ padding: 0 }}>
            <Row cells={[['', '40px'], ['日時', '1.6fr', 'mono'], ['種類', '0.8fr'], ['内容', '1.4fr'], ['レコード数', '1fr', 'mono'], ['', '1fr']]}
              header style={{ padding: '10px 14px', background: PAPER_2 }} />
            {sessions.map(([date, type, content, records, selected], i) => (
              <Row key={date} cells={[
                [<div key="c" style={{
                  width: 18, height: 18, border: `1.5px solid ${selected ? INK : INK_MUTE}`,
                  background: selected ? INK : 'transparent', borderRadius: 3, flexShrink: 0,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  {selected && <div style={{ width: 8, height: 8, background: PAPER, borderRadius: 1 }} />}
                </div>, '40px'],
                [date, '1.6fr', 'mono'],
                [<Pill key="p" accent={type === 'learning' ? 'READY' : undefined}>{type}</Pill>, '0.8fr'],
                [content, '1.4fr'],
                [records, '1fr', 'mono'],
                [<Btn key="b" primary={selected}>{selected ? '✓ 選択中' : '選択'}</Btn>, '1fr'],
              ]} style={{
                padding: '10px 14px',
                background: selected ? '#f4f1e6' : 'transparent',
                borderBottom: `1px dashed ${INK_MUTE}`,
              }} />
            ))}
          </Box>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <Box label="選択中のログ" style={{ padding: '14px 16px' }}>
              <div style={{ fontSize: 15, fontWeight: 700 }}>2026-05-12 13:42</div>
              <div style={{ fontSize: 13, color: INK_SOFT, marginTop: 4 }}>学習運転 · 41パターン</div>
              <div style={{ fontSize: 13, color: INK_SOFT }}>62,400 レコード</div>
              <div style={{ borderTop: `1px dashed ${INK_MUTE}`, margin: '10px 0' }} />
              <div style={{ fontSize: 13, color: INK_SOFT }}>前回モデル:</div>
              <div style={{ fontSize: 13, fontFamily: 'monospace' }}>2026-05-08 · P95 ±0.21</div>
            </Box>
            <Note>学習ログ (learning) を推奨。走行ログ (auto) からも再学習できますが精度が低下する場合があります。</Note>
            <div style={{ flex: 1 }} />
            <Btn primary big style={{ padding: '14px' }}>▶ このログでモデル学習を実行</Btn>
          </div>
        </div>
      </div>
    </Frame>
  );
}

// ── タイムスケジュール — 一覧
function TimeScheduleListScreen({ state }) {
  const schedules = [
    ['アイドリング保持 5分', '300s', 3, 'acc 0% / brk 0%'],
    ['アクセル段階踏み込み', '120s', 6, '0→25→50→75%'],
    ['ブレーキ耐久テスト', '600s', 12, 'brk 0→80→0%繰り返し'],
  ];
  return (
    <Frame state={state || 'READY'} screen="タイムスケジュール" activeNav="schedule">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, height: '100%' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <H2 sub="時刻×開度の表形式で自動操作をプログラム。基準車速CSVなしで動作可能。（Post-MVP · P1）">タイムスケジュール</H2>
          <div style={{ flex: 1 }} />
          <Pill>Post-MVP (P1)</Pill>
          <Btn primary big>+ 新規スケジュール</Btn>
        </div>
        <Box style={{ padding: 0 }}>
          <Row cells={[['名前', '2fr'], ['総時間', '1fr', 'mono'], ['ステップ数', '1fr', 'mono'], ['概要', '2fr'], ['操作', '1fr']]}
            header style={{ padding: '10px 14px', background: PAPER_2 }} />
          {schedules.map(([name, dur, steps, desc]) => (
            <Row key={name} cells={[
              [<b key="n">{name}</b>, '2fr'],
              [dur, '1fr', 'mono'],
              [`${steps}ステップ`, '1fr', 'mono'],
              [desc, '2fr'],
              [<div key="b" style={{ display: 'flex', gap: 6 }}>
                <Btn primary>実行</Btn><Btn>編集</Btn>
              </div>, '1fr'],
            ]} style={{ padding: '10px 14px', borderBottom: `1px dashed ${INK_MUTE}` }} />
          ))}
        </Box>
      </div>
    </Frame>
  );
}

// ── タイムスケジュール — 編集
function TimeScheduleEditScreen({ state }) {
  const rows = [
    [0,   0.0, 0.0, '開始'],
    [10,  0.0, 0.0, '待機'],
    [30,  25.0, 0.0, 'アクセル踏み込み'],
    [60,  50.0, 0.0, ''],
    [90,  75.0, 0.0, ''],
    [120, 0.0,  0.0, '戻し'],
    [150, 0.0, 30.0, 'ブレーキ'],
    [180, 0.0,  0.0, '終了'],
  ];

  return (
    <Frame state={state || 'READY'} screen="タイムスケジュール — 編集" activeNav="schedule">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, height: '100%' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Btn>← 一覧</Btn>
          <H2 sub="時刻 [s] とアクセル/ブレーキ開度 [%] を設定します">アクセル段階踏み込み</H2>
          <div style={{ flex: 1 }} />
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 14, color: INK_SOFT }}>
            <span>ループ:</span>
            <div style={{ border: `1.3px solid ${INK}`, padding: '3px 10px', borderRadius: 3, background: PAPER, fontSize: 14 }}>1 回</div>
          </div>
          <Btn primary big>保存</Btn>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 12, flex: 1 }}>
          {/* テーブル */}
          <Box label="タイムスケジュール表" style={{ padding: 0, display: 'flex', flexDirection: 'column' }}>
            <Row cells={[['時刻 [s]', '1fr', 'mono'], ['アクセル [%]', '1fr', 'mono'], ['ブレーキ [%]', '1fr', 'mono'], ['コメント', '2fr'], ['', '60px']]}
              header style={{ padding: '10px 14px', background: PAPER_2 }} />
            {rows.map(([t, acc, brk, comment], i) => (
              <Row key={i} cells={[
                [<div key="t" style={{ fontFamily: 'monospace', background: PAPER_2, border: `1px solid ${INK_MUTE}`, padding: '3px 8px', borderRadius: 2 }}>{t}</div>, '1fr'],
                [<div key="a" style={{ fontFamily: 'monospace', background: PAPER_2, border: `1px solid ${INK_MUTE}`, padding: '3px 8px', borderRadius: 2 }}>{acc.toFixed(1)}</div>, '1fr'],
                [<div key="b" style={{ fontFamily: 'monospace', background: PAPER_2, border: `1px solid ${INK_MUTE}`, padding: '3px 8px', borderRadius: 2 }}>{brk.toFixed(1)}</div>, '1fr'],
                [<div key="c" style={{ background: PAPER_2, border: `1px solid ${INK_MUTE}`, padding: '3px 8px', borderRadius: 2, fontSize: 13, color: INK_SOFT }}>{comment || '—'}</div>, '2fr'],
                [<Btn key="x" ghost style={{ fontSize: 12, padding: '2px 8px' }}>× 削除</Btn>, '60px'],
              ]} style={{ padding: '6px 14px', borderBottom: `1px dashed ${INK_MUTE}` }} />
            ))}
            <div style={{ padding: '8px 14px' }}>
              <Btn>+ 行を追加</Btn>
            </div>
          </Box>

          {/* プレビューグラフ */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <Box label="開度プレビュー (アクセル: 黒 / ブレーキ: 赤)" style={{ padding: 12 }}>
              <svg viewBox="0 0 340 180" width="100%" height="180">
                {/* axes */}
                <rect x={30} y={10} width={300} height={140} fill="none" stroke={INK} strokeWidth="1.2" />
                {[0, 25, 50, 75, 100].map(v => {
                  const y = 10 + (1 - v / 100) * 140;
                  return (
                    <g key={v}>
                      <text x={26} y={y + 4} fontSize="9" textAnchor="end" fontFamily="monospace" fill={INK_SOFT}>{v}</text>
                      <line x1={30} y1={y} x2={330} y2={y} stroke={HATCH} strokeWidth="0.6" strokeDasharray="2 3" />
                    </g>
                  );
                })}
                {/* accel step line */}
                {rows.map(([t, acc], i) => {
                  const x = 30 + (t / 180) * 300;
                  const y = 10 + (1 - acc / 100) * 140;
                  const nx = i + 1 < rows.length ? 30 + (rows[i + 1][0] / 180) * 300 : x;
                  return (
                    <g key={i}>
                      <line x1={x} y1={y} x2={nx} y2={y} stroke={INK} strokeWidth="2" />
                      {i + 1 < rows.length && (
                        <line x1={nx} y1={y} x2={nx} y2={10 + (1 - rows[i + 1][1] / 100) * 140} stroke={INK} strokeWidth="2" />
                      )}
                    </g>
                  );
                })}
                {/* brake step line */}
                {rows.map(([t, , brk], i) => {
                  const x = 30 + (t / 180) * 300;
                  const y = 10 + (1 - brk / 100) * 140;
                  const nx = i + 1 < rows.length ? 30 + (rows[i + 1][0] / 180) * 300 : x;
                  const ny = i + 1 < rows.length ? 10 + (1 - rows[i + 1][2] / 100) * 140 : y;
                  return (
                    <g key={i}>
                      <line x1={x} y1={y} x2={nx} y2={y} stroke="#a23232" strokeWidth="2" />
                      {i + 1 < rows.length && <line x1={nx} y1={y} x2={nx} y2={ny} stroke="#a23232" strokeWidth="2" />}
                    </g>
                  );
                })}
                <text x={180} y={170} fontSize="10" textAnchor="middle" fontFamily="monospace" fill={INK_SOFT}>時刻 [s] →</text>
              </svg>
            </Box>
            <Box label="走行前チェック" style={{ padding: 12, fontSize: 14, color: INK_SOFT }}>
              <div>スケジュール実行前にも走行前チェック (6項目) が実施されます。</div>
              <div style={{ marginTop: 8 }}><Btn primary style={{ width: '100%' }}>▶ スケジュールを実行</Btn></div>
            </Box>
          </div>
        </div>
      </div>
    </Frame>
  );
}

// ── シーケンス — 一覧
function SequenceListScreen({ state }) {
  const sequences = [
    ['朝の暖機シーケンス', 3, '手動 5分 → WLTP × 2'],
    ['耐久テストフル', 5, 'WLTP × 3 → JC08 → 冷却待機'],
    ['ブレーキ評価', 4, 'ブレーキテスト × 2 → WLTP'],
  ];
  return (
    <Frame state={state || 'READY'} screen="シーケンス" activeNav="sequence">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, height: '100%' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <H2 sub="走行モードとタイムスケジュールを任意の順序で組み合わせ、連続実行します。（Post-MVP · P1）">シーケンス</H2>
          <div style={{ flex: 1 }} />
          <Pill>Post-MVP (P1)</Pill>
          <Btn primary big>+ 新規シーケンス</Btn>
        </div>
        <Box style={{ padding: 0 }}>
          <Row cells={[['名前', '2fr'], ['ステップ数', '1fr', 'mono'], ['内容', '3fr'], ['操作', '1fr']]}
            header style={{ padding: '10px 14px', background: PAPER_2 }} />
          {sequences.map(([name, steps, desc]) => (
            <Row key={name} cells={[
              [<b key="n">{name}</b>, '2fr'],
              [`${steps}ステップ`, '1fr', 'mono'],
              [desc, '3fr'],
              [<div key="b" style={{ display: 'flex', gap: 6 }}>
                <Btn primary>実行</Btn><Btn>編集</Btn>
              </div>, '1fr'],
            ]} style={{ padding: '10px 14px', borderBottom: `1px dashed ${INK_MUTE}` }} />
          ))}
        </Box>
      </div>
    </Frame>
  );
}

// ── シーケンス — 編集
function SequenceEditScreen({ state }) {
  const steps = [
    { type: 'schedule', name: 'アイドリング保持 5分', duration: '300s', color: '#dde6f0' },
    { type: 'mode',     name: 'WLTP_Class3',           duration: '1800s', color: '#dfeadc' },
    { type: 'mode',     name: 'WLTP_Class3',           duration: '1800s', color: '#dfeadc' },
    { type: 'schedule', name: 'ブレーキ耐久テスト',    duration: '600s',  color: '#faf3dc' },
    { type: 'mode',     name: 'JC08',                  duration: '1204s', color: '#dfeadc' },
  ];
  const totalSec = steps.reduce((a, s) => a + parseInt(s.duration), 0);

  return (
    <Frame state={state || 'READY'} screen="シーケンス — 編集" activeNav="sequence">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, height: '100%' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Btn>← 一覧</Btn>
          <H2 sub="走行モードとタイムスケジュールをドラッグで並べ替えできます">耐久テストフル</H2>
          <div style={{ flex: 1 }} />
          <div style={{ fontSize: 14, color: INK_SOFT }}>総時間: <b style={{ fontFamily: 'monospace' }}>{Math.round(totalSec / 60)}分</b></div>
          <Btn primary big>保存</Btn>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 14, flex: 1 }}>
          {/* ステップリスト */}
          <Box label="ステップ (ドラッグで並べ替え)" style={{ padding: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
            {steps.map(({ type, name, duration, color }, i) => (
              <div key={i} style={{
                display: 'flex', alignItems: 'center', gap: 12,
                padding: '10px 14px',
                border: `1.5px solid ${INK}`,
                background: color,
                borderRadius: 4,
              }}>
                <div style={{ fontSize: 18, color: INK_MUTE, cursor: 'grab' }}>⠿</div>
                <div style={{
                  width: 28, height: 28, borderRadius: '50%',
                  border: `1.4px solid ${INK}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 13, fontWeight: 700, flexShrink: 0,
                }}>{i + 1}</div>
                <Pill>{type === 'mode' ? '走行モード' : 'スケジュール'}</Pill>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 16, fontWeight: 700 }}>{name}</div>
                  <div style={{ fontSize: 12, color: INK_SOFT, fontFamily: 'monospace' }}>{duration}</div>
                </div>
                <Btn ghost style={{ fontSize: 12 }}>× 削除</Btn>
              </div>
            ))}
            {/* 追加ボタン */}
            <div style={{ display: 'flex', gap: 8 }}>
              <Btn>+ 走行モードを追加</Btn>
              <Btn>+ スケジュールを追加</Btn>
            </div>
          </Box>

          {/* サイドパネル */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <Box label="凡例" style={{ padding: 12 }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8, fontSize: 14 }}>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <div style={{ width: 20, height: 14, background: '#dfeadc', border: `1px solid ${INK}` }} />
                  <span>走行モード (CSV 基準車速)</span>
                </div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <div style={{ width: 20, height: 14, background: '#dde6f0', border: `1px solid ${INK}` }} />
                  <span>タイムスケジュール</span>
                </div>
              </div>
            </Box>
            <Box label="合計" style={{ padding: 12 }}>
              <div style={{ fontSize: 14, color: INK_SOFT }}>ステップ数</div>
              <div style={{ fontSize: 28, fontFamily: 'monospace', fontWeight: 700 }}>{steps.length}</div>
              <div style={{ fontSize: 14, color: INK_SOFT, marginTop: 8 }}>推定総時間</div>
              <div style={{ fontSize: 28, fontFamily: 'monospace', fontWeight: 700 }}>{Math.round(totalSec / 60)}<span style={{ fontSize: 16, color: INK_SOFT }}> 分</span></div>
            </Box>
            <Note>各ステップの走行前チェックは実行直前に自動で行われます。1つでもNGなら停止します。</Note>
            <div style={{ flex: 1 }} />
            <Btn primary big style={{ padding: '14px' }}>▶ シーケンスを実行</Btn>
          </div>
        </div>
      </div>
    </Frame>
  );
}

Object.assign(window, {
  ModelTrainingScreen,
  ModelTrainingDoneScreen,
  CalibrationErrorScreen,
  RetrainSelectLogScreen,
  TimeScheduleListScreen,
  TimeScheduleEditScreen,
  SequenceListScreen,
  SequenceEditScreen,
});
