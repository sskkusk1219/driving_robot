// Auto Drive Monitor — 5 variations

// ── A1 Graph-focused — large speed graph as the hero
function AutoDriveA({ state }) {
  return (
    <Frame state={state || 'RUNNING'} screen="自動走行モニター" activeNav="auto">
      <div style={{ display: 'grid', gridTemplateRows: 'auto 1fr auto', gap: 14, height: '100%' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <Pill accent="RUNNING">RUNNING</Pill>
          <div style={{ fontSize: 20, fontWeight: 700 }}>WLTP_Class3</div>
          <div style={{ fontSize: 14, color: INK_SOFT }}>session #2483 · 13:42 開始</div>
          <div style={{ flex: 1 }} />
          <Btn>一時停止</Btn>
          <Btn danger big>■ 走行停止</Btn>
        </div>
        <Box label="基準車速 vs 実車速" style={{ padding: 14 }}>
          <SpeedGraph width="100%" height={460} progress={0.42} />
        </Box>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', gap: 14, alignItems: 'center' }}>
          <TimeProgress elapsed={760} total={1800} />
          <Box style={{ padding: '6px 10px' }}>
            <div style={{ fontSize: 12, color: INK_SOFT }}>偏差 [km/h]</div>
            <div style={{ fontSize: 24, fontFamily: 'monospace', fontWeight: 700 }}>+0.18</div>
          </Box>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
            <PedalBar label="アクセル" value={42.3} width={120} />
          </div>
        </div>
      </div>
    </Frame>
  );
}

// ── A2 Split — graph + numbers + pedal cockpit
function AutoDriveB({ state }) {
  return (
    <Frame state={state || 'RUNNING'} screen="自動走行モニター · スプリット" activeNav="auto">
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 14, height: '100%' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Box label="基準 vs 実車速" style={{ padding: 10 }}>
            <SpeedGraph width="100%" height={290} progress={0.42} />
          </Box>
          <Box label="アクセル開度 / ブレーキ開度" style={{ padding: 10 }}>
            <Hatch width="100%" height={170} label="opening % vs time (sketch)" />
          </Box>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <Box style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-around', padding: 12 }}>
            <BigSpeed value={62.4} refSpeed={60.0} size={170} />
          </Box>
          <Box label="ペダル開度" style={{ display: 'flex', justifyContent: 'space-around', padding: 14 }}>
            <PedalGauge label="アクセル" value={42.3} height={120} width={50} />
            <PedalGauge label="ブレーキ" value={0} height={120} width={50} color="#a23232" />
          </Box>
          <Box label="進捗">
            <TimeProgress elapsed={760} total={1800} />
            <div style={{ fontSize: 13, color: INK_SOFT, marginTop: 6 }}>逸脱回数: <b>0</b> · 平均偏差: <b>0.12 km/h</b></div>
          </Box>
          <div style={{ flex: 1 }} />
          <Btn danger big style={{ padding: '14px' }}>■ 走行停止</Btn>
          <EmergencyBtn size={90} style={{ alignSelf: 'center' }} />
        </div>
      </div>
    </Frame>
  );
}

// ── A3 Strip — single ribbon graph + ticker
function AutoDriveC({ state }) {
  return (
    <Frame state={state || 'RUNNING'} screen="自動走行モニター · ストリップ" activeNav="auto">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, height: '100%' }}>
        <Box style={{ display: 'flex', alignItems: 'center', padding: '10px 16px', gap: 18 }}>
          <div>
            <div style={{ fontSize: 12, color: INK_SOFT }}>実車速</div>
            <div style={{ fontSize: 44, fontWeight: 800, lineHeight: 1, fontFamily: 'inherit' }}>62.4</div>
          </div>
          <div style={{ width: 1, height: 50, background: INK_MUTE }} />
          <div>
            <div style={{ fontSize: 12, color: INK_SOFT }}>基準</div>
            <div style={{ fontSize: 28, fontFamily: 'monospace' }}>60.0</div>
          </div>
          <div>
            <div style={{ fontSize: 12, color: INK_SOFT }}>偏差</div>
            <div style={{ fontSize: 28, fontFamily: 'monospace' }}>+0.18</div>
          </div>
          <div style={{ flex: 1 }} />
          <Pill accent="RUNNING">42.2% / 1800s</Pill>
          <Btn danger big>■ 停止</Btn>
        </Box>
        <Box label="基準（破線）と実車速（実線）― 進行中" style={{ padding: 10, flex: 1 }}>
          <SpeedGraph width="100%" height={300} progress={0.42} />
          <TimeProgress elapsed={760} total={1800} style={{ marginTop: 8 }} />
        </Box>
        <Box label="リアルタイムログ（最新10行）" style={{ padding: '8px 12px' }}>
          <div style={{ fontFamily: 'monospace', fontSize: 12, color: INK_SOFT, lineHeight: 1.7 }}>
            13:54:46.100  ref=60.0  act=62.4  acc=42.3  brk=0.0  Δ=+0.18<br/>
            13:54:46.000  ref=60.0  act=62.3  acc=42.5  brk=0.0  Δ=+0.32<br/>
            13:54:45.900  ref=60.0  act=62.1  acc=42.8  brk=0.0  Δ=+0.05<br/>
            13:54:45.800  ref=59.8  act=61.9  acc=43.0  brk=0.0  Δ=−0.12<br/>
          </div>
        </Box>
      </div>
    </Frame>
  );
}

// ── A4 — 3-axis layout:
//   1・2軸: rolling window (直近~13分を拡大表示)
//   3軸: 独立x軸・全体プロファイル + 現在位置マーカー
//   グラフ幅: 全軸共通 PL=50 PR=16 PW=834
function AutoDriveD({ state, activeNav = 'auto', screen = '自動走行モニター', showPause = true }) {
  const [confirmStop, setConfirmStop] = React.useState(false);
  const [paused, setPaused] = React.useState(false);
  const progress  = 0.42;
  const N         = 120;      // total sample count
  const totalSec  = 1800;     // 30 min session

  // ── 全軸共通: グラフ幅パラメータ ──────────────────────
  const VW = 900, PL = 50, PR = 16, PW = VW - PL - PR; // PW = 834

  // ── データ生成 ──────────────────────────────────────
  const speedRef = Array.from({ length: N + 1 }, (_, i) => {
    const t = i / N;
    const v = 60 + 50 * Math.sin(t * Math.PI * 3.2) * (0.5 + 0.5 * Math.sin(t * Math.PI * 1.3)) + 15 * Math.sin(t * Math.PI * 7);
    return Math.max(0, Math.min(120, v + 30));
  });
  const speedAct = speedRef.map((v, i) => {
    const lag = i > 0 ? speedRef[i - 1] : v;
    return Math.max(0, v * 0.7 + lag * 0.3 + Math.sin(i * 0.7) * 1.6);
  });
  const openingData = Array.from({ length: N + 1 }, (_, i) => {
    const t = i / N;
    const acc = 40 + 35 * Math.sin(t * Math.PI * 2.8 + 0.5) * (0.5 + 0.4 * Math.cos(t * Math.PI * 1.2)) + 5 * Math.sin(t * Math.PI * 7);
    const brk = Math.max(0, 22 * Math.sin(t * Math.PI * 3.1 + Math.PI * 0.6) * (0.4 + 0.3 * Math.cos(t * Math.PI * 1.5)));
    return { acc: Math.max(0, Math.min(100, acc)), brk: Math.max(0, Math.min(100, brk)) };
  });

  // ── 1・2軸: ローリングウィンドウ (直近55サンプル, 現在位置を70%に配置) ──
  const WIN        = 55;
  const currentIdx = Math.floor(N * progress);                        // ≈ 50
  const winStart   = Math.max(0, Math.min(currentIdx - Math.round(WIN * 0.70), N - WIN)); // ≈ 11
  const winEnd     = Math.min(N, winStart + WIN);                     // ≈ 66
  const curFracWin = (currentIdx - winStart) / WIN;
  const curXWin    = (PL + curFracWin * PW).toFixed(1);
  const xWin       = (i) => (PL + ((i - winStart) / WIN) * PW).toFixed(1);

  // ローリングウィンドウ x軸ラベル (2分刻み)
  const winStartSec = Math.round((winStart / N) * totalSec);
  const winEndSec   = Math.round((winEnd   / N) * totalSec);
  const winLabels   = [];
  const winStep     = 120; // 2 min
  for (let s = Math.ceil(winStartSec / winStep) * winStep; s <= winEndSec; s += winStep) {
    const frac = (s - winStartSec) / (winEndSec - winStartSec);
    const mm = Math.floor(s / 60), ss2 = String(s % 60).padStart(2, '0');
    winLabels.push({ x: (PL + frac * PW).toFixed(1), label: `${mm}:${ss2}` });
  }

  // ── 3軸: 全体プロファイル ──
  const curXFull = (PL + progress * PW).toFixed(1);
  const xFull    = (i) => (PL + (i / N) * PW).toFixed(1);

  // 経過領域フィル (基準曲線の下)
  const elapsedFill = [
    `M${PL},${0}`,
    ...speedRef.slice(0, currentIdx + 1).map((v, i) => {
      // yAt inline — computed inside the render below
      return `__placeholder_${i}_${v}`;
    }),
  ].join(' ');
  // ※ elapsedFill は SVG内で直接計算するので、ここはダミー。実際はrender内で構築。

  return (
    <div style={{ position: 'relative', width: '100%', height: '100%' }}>
      <Frame state={state || 'RUNNING'} screen={screen} activeNav={activeNav}>
      <div style={{ display: 'grid', gridTemplateRows: '1fr 1fr auto auto', gap: 10, height: '100%' }}>

        {/* ────────────────────────────────────────────
            1軸目: 基準車速 vs 実車速  [rolling window]
        ──────────────────────────────────────────── */}
        <Box label="1軸目 · 基準車速 vs 実車速 [km/h]  —  直近 13分ウィンドウ" style={{ padding: '8px 10px', display: 'flex', flexDirection: 'column', minHeight: 0 }}>
          {(() => {
            const H = 170, PT = 14, PB = 22, PH = H - PT - PB;
            const yAt = (v) => (PT + (1 - v / 130) * PH).toFixed(1);
            const refPath = Array.from({ length: winEnd - winStart + 1 }, (_, j) => {
              const i = winStart + j;
              return `${j === 0 ? 'M' : 'L'}${xWin(i)},${yAt(speedRef[i])}`;
            }).join(' ');
            const actLen  = Math.max(0, Math.min(currentIdx - winStart + 1, winEnd - winStart + 1));
            const actPath = Array.from({ length: actLen }, (_, j) => {
              const i = winStart + j;
              return `${j === 0 ? 'M' : 'L'}${xWin(i)},${(PT + (1 - speedAct[i] / 130) * PH).toFixed(1)}`;
            }).join(' ');
            return (
              <svg viewBox={`0 0 ${VW} ${H}`} width="100%" height={H} preserveAspectRatio="none" style={{ display: 'block' }}>
                <rect x={PL} y={PT} width={PW} height={PH} fill="none" stroke={INK} strokeWidth="1.2" />
                {[0, 40, 80, 120].map(v => {
                  const y = yAt(v);
                  return (
                    <g key={v}>
                      <line x1={PL - 4} y1={y} x2={PL} y2={y} stroke={INK} strokeWidth="1" />
                      <text x={PL - 6} y={parseFloat(y) + 4} fontSize="11" textAnchor="end" fontFamily="monospace" fill={INK_SOFT}>{v}</text>
                      <line x1={PL} y1={y} x2={PL + PW} y2={y} stroke={HATCH} strokeWidth="0.7" strokeDasharray="2 3" />
                    </g>
                  );
                })}
                {winLabels.map(({ x, label }) => (
                  <g key={label}>
                    <line x1={x} y1={PT + PH} x2={x} y2={PT + PH + 4} stroke={INK} strokeWidth="0.8" />
                    <text x={x} y={H - 2} fontSize="10" textAnchor="middle" fontFamily="monospace" fill={INK_SOFT}>{label}</text>
                  </g>
                ))}
                <path d={refPath} fill="none" stroke={INK} strokeWidth="1.5" strokeDasharray="4 3" />
                <path d={actPath} fill="none" stroke="#2f5780" strokeWidth="2.2" />
                <line x1={curXWin} y1={PT} x2={curXWin} y2={PT + PH} stroke="#a23232" strokeWidth="1.4" strokeDasharray="3 3" />
                <line x1={PL + 10} y1={PT + 10} x2={PL + 30} y2={PT + 10} stroke={INK} strokeWidth="1.5" strokeDasharray="4 3" />
                <text x={PL + 36} y={PT + 14} fontSize="12" fontFamily="inherit" fill={INK}>基準</text>
                <line x1={PL + 76} y1={PT + 10} x2={PL + 96} y2={PT + 10} stroke="#2f5780" strokeWidth="2.2" />
                <text x={PL + 102} y={PT + 14} fontSize="12" fontFamily="inherit" fill={INK}>実測</text>
                <text x={PL - 6} y={PT - 2} fontSize="11" fontFamily="monospace" fill={INK_SOFT}>km/h</text>
                <text x={PL + PW / 2} y={H - 2} fontSize="11" textAnchor="middle" fontFamily="monospace" fill={INK_SOFT}>mm:ss →</text>
              </svg>
            );
          })()}
          <div style={{ display: 'flex', gap: 14, fontSize: 12, color: INK_SOFT, marginTop: 3 }}>
            <span>実車速 <b style={{ fontFamily: 'monospace', color: INK }}>62.4</b> km/h</span>
            <span>基準 <b style={{ fontFamily: 'monospace', color: INK }}>60.0</b></span>
            <span>偏差 <b style={{ fontFamily: 'monospace', color: INK }}>+0.18</b></span>
            <span>P95 <b style={{ fontFamily: 'monospace', color: INK }}>0.14</b></span>
            <span>逸脱継続 <b style={{ fontFamily: 'monospace', color: INK }}>0.0s / 4.0s</b></span>
          </div>
        </Box>

        {/* ────────────────────────────────────────────
            2軸目: アクセル / ブレーキ開度  [rolling window]
        ──────────────────────────────────────────── */}
        <Box label="2軸目 · アクセル / ブレーキ開度 [%]  —  直近 13分ウィンドウ" style={{ padding: '8px 10px', display: 'flex', flexDirection: 'column', minHeight: 0 }}>
          {(() => {
            const H = 155, PT = 12, PB = 22, PH = H - PT - PB;
            const yAt = (v) => (PT + (1 - v / 100) * PH).toFixed(1);
            const actLen     = Math.max(0, Math.min(currentIdx - winStart + 1, winEnd - winStart + 1));
            // 基準アクセル開度 (ウィンドウ全体・点線・薄い)
            const accRefPath = Array.from({ length: winEnd - winStart + 1 }, (_, j) => {
              const i = winStart + j;
              return `${j === 0 ? 'M' : 'L'}${xWin(i)},${yAt(openingData[i].acc)}`;
            }).join(' ');
            // 実績アクセル (現在位置まで)
            const accActPath = Array.from({ length: actLen }, (_, j) => {
              const i = winStart + j;
              return `${j === 0 ? 'M' : 'L'}${xWin(i)},${yAt(openingData[i].acc)}`;
            }).join(' ');
            // ブレーキ (現在位置まで)
            const brkActPath = Array.from({ length: actLen }, (_, j) => {
              const i = winStart + j;
              return `${j === 0 ? 'M' : 'L'}${xWin(i)},${yAt(openingData[i].brk)}`;
            }).join(' ');
            return (
              <svg viewBox={`0 0 ${VW} ${H}`} width="100%" height={H} preserveAspectRatio="none" style={{ display: 'block' }}>
                <rect x={PL} y={PT} width={PW} height={PH} fill="none" stroke={INK} strokeWidth="1.2" />
                {[0, 25, 50, 75, 100].map(v => {
                  const y = yAt(v);
                  return (
                    <g key={v}>
                      <text x={PL - 6} y={parseFloat(y) + 4} fontSize="11" textAnchor="end" fontFamily="monospace" fill={INK_SOFT}>{v}</text>
                      <line x1={PL} y1={y} x2={PL + PW} y2={y} stroke={HATCH} strokeWidth="0.7" strokeDasharray="2 3" />
                    </g>
                  );
                })}
                {winLabels.map(({ x, label }) => (
                  <g key={label}>
                    <line x1={x} y1={PT + PH} x2={x} y2={PT + PH + 4} stroke={INK} strokeWidth="0.8" />
                    <text x={x} y={H - 2} fontSize="10" textAnchor="middle" fontFamily="monospace" fill={INK_SOFT}>{label}</text>
                  </g>
                ))}
                <path d={accRefPath} fill="none" stroke={INK} strokeWidth="1.2" strokeDasharray="5 3" opacity="0.30" />
                <path d={accActPath} fill="none" stroke={INK} strokeWidth="2.2" />
                <path d={brkActPath} fill="none" stroke="#a23232" strokeWidth="2.2" />
                <line x1={curXWin} y1={PT} x2={curXWin} y2={PT + PH} stroke="#a23232" strokeWidth="1.4" strokeDasharray="3 3" />
                <line x1={PL + 10} y1={PT + 10} x2={PL + 30} y2={PT + 10} stroke={INK} strokeWidth="2.2" />
                <text x={PL + 36} y={PT + 14} fontSize="12" fontFamily="inherit" fill={INK}>アクセル</text>
                <line x1={PL + 122} y1={PT + 10} x2={PL + 142} y2={PT + 10} stroke="#a23232" strokeWidth="2.2" />
                <text x={PL + 148} y={PT + 14} fontSize="12" fontFamily="inherit" fill={INK}>ブレーキ</text>
                <text x={PL - 6} y={PT - 2} fontSize="11" fontFamily="monospace" fill={INK_SOFT}>%</text>
                <text x={PL + PW / 2} y={H - 2} fontSize="11" textAnchor="middle" fontFamily="monospace" fill={INK_SOFT}>mm:ss →</text>
              </svg>
            );
          })()}
          <div style={{ display: 'flex', gap: 14, fontSize: 12, color: INK_SOFT, marginTop: 3 }}>
            <span>アクセル <b style={{ fontFamily: 'monospace', color: INK }}>42.3 %</b></span>
            <span>ブレーキ <b style={{ fontFamily: 'monospace', color: INK }}>0.0 %</b></span>
          </div>
        </Box>

        {/* ────────────────────────────────────────────
            3軸目: 全体プロファイル — 独立x軸 (0→30min)
            ・基準車速プロファイル全体を表示
            ・経過実績 (青実線) と現在位置マーカー (赤)
            ・経過領域をライトブルーでフィル
        ──────────────────────────────────────────── */}
        <Box label="3軸目 · 全体プロファイル — 独立x軸 (0 → 30:00)  ·  現在位置マーカー" style={{ padding: '6px 10px' }}>
          {(() => {
            const H = 110, PT = 16, PB = 18, PH = H - PT - PB;
            const yAt = (v) => (PT + (1 - v / 130) * PH).toFixed(1);

            // 基準プロファイル全体 (破線)
            const refPath = speedRef.map((v, i) => `${i === 0 ? 'M' : 'L'}${xFull(i)},${yAt(v)}`).join(' ');

            // 実績 (現在位置まで・実線)
            const actPath = speedAct.slice(0, currentIdx + 1).map((v, i) =>
              `${i === 0 ? 'M' : 'L'}${xFull(i)},${(PT + (1 - v / 130) * PH).toFixed(1)}`
            ).join(' ');

            // 経過領域フィル (基準曲線 → 底辺)
            const fillPath = [
              `M${PL},${PT + PH}`,
              ...speedRef.slice(0, currentIdx + 1).map((v, i) => `L${xFull(i)},${yAt(v)}`),
              `L${curXFull},${PT + PH}`,
              'Z'
            ].join(' ');

            // x軸ラベル: 5分刻み
            const fullLabels = [];
            for (let s = 0; s <= totalSec; s += 300) {
              const x = (PL + (s / totalSec) * PW).toFixed(1);
              fullLabels.push({ x, label: `${s / 60}m` });
            }

            const cx = parseFloat(curXFull);

            return (
              <svg viewBox={`0 0 ${VW} ${H}`} width="100%" height={H} preserveAspectRatio="none" style={{ display: 'block' }}>
                {/* 経過領域フィル */}
                <path d={fillPath} fill="#2f5780" fillOpacity="0.10" />

                <rect x={PL} y={PT} width={PW} height={PH} fill="none" stroke={INK} strokeWidth="1" />

                {/* y軸ティック */}
                {[0, 60, 120].map(v => {
                  const y = yAt(v);
                  return (
                    <g key={v}>
                      <line x1={PL - 4} y1={y} x2={PL} y2={y} stroke={INK} strokeWidth="0.8" />
                      <text x={PL - 6} y={parseFloat(y) + 4} fontSize="10" textAnchor="end" fontFamily="monospace" fill={INK_SOFT}>{v}</text>
                      <line x1={PL} y1={y} x2={PL + PW} y2={y} stroke={HATCH} strokeWidth="0.5" strokeDasharray="2 4" />
                    </g>
                  );
                })}

                {/* x軸ラベル (5分刻み) */}
                {fullLabels.map(({ x, label }) => (
                  <g key={label}>
                    <line x1={x} y1={PT + PH} x2={x} y2={PT + PH + 4} stroke={INK} strokeWidth="0.8" />
                    <text x={x} y={H - 1} fontSize="10" textAnchor="middle" fontFamily="monospace" fill={INK_SOFT}>{label}</text>
                  </g>
                ))}

                {/* 基準プロファイル全体 (破線) */}
                <path d={refPath} fill="none" stroke={INK} strokeWidth="1.2" strokeDasharray="4 3" opacity="0.55" />

                {/* 実績 (現在位置まで) */}
                <path d={actPath} fill="none" stroke="#2f5780" strokeWidth="2" />

                {/* 現在位置ライン */}
                <line x1={cx} y1={PT - 6} x2={cx} y2={PT + PH + 2} stroke="#a23232" strokeWidth="2" />

                {/* ▼ マーカー (上) */}
                <text x={cx} y={PT - 7} fontSize="13" textAnchor="middle" fill="#a23232">▼</text>

                {/* 現在時刻ラベル */}
                <text x={cx + 7} y={PT + 15} fontSize="11" fontFamily="monospace" fill="#a23232" fontWeight="bold">13:54</text>

                {/* 残り時間ヒント */}
                <text x={cx + 7} y={PT + PH - 4} fontSize="10" fontFamily="monospace" fill={INK_SOFT}>残 17:20</text>

                {/* y軸ラベル */}
                <text x={PL + 2} y={PT - 4} fontSize="10" fontFamily="monospace" fill={INK_SOFT}>km/h</text>
              </svg>
            );
          })()}
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, fontFamily: 'monospace', marginTop: 3, padding: '0 2px' }}>
            <span style={{ color: INK_SOFT }}>開始: <b style={{ color: INK }}>13:42:08</b></span>
            <span style={{ color: '#a23232', fontWeight: 700 }}>▲ 現在 13:54:48  (42%  ·  756 / 1800 s)</span>
            <span style={{ color: INK_SOFT }}>終了予定: <b style={{ color: INK }}>14:12:08</b></span>
          </div>
        </Box>

        {/* ── 下段: 現在車速 + プロファイル | セッション + ボタン ── */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <Box style={{ display: 'flex', gap: 12, alignItems: 'center', padding: 12 }}>
            <BigSpeed value={62.4} refSpeed={60.0} size={110} />
            <Box label="プロファイル" style={{ flex: 1, padding: '8px 12px' }}>
              <div style={{ fontSize: 15, fontWeight: 700 }}>Prius_2024</div>
              <div style={{ fontSize: 12, color: INK_SOFT, marginTop: 4 }}>WLTP_Class3</div>
              <div style={{ fontSize: 12, color: INK_SOFT }}>±2.0km/h · 4.0s</div>
              <div style={{ fontSize: 12, color: INK_SOFT }}>Kp/Ki/Kd: 1.2 / 0.05 / 0.3</div>
            </Box>
          </Box>
          <div style={{ display: 'flex', gap: 10, alignItems: 'stretch' }}>
            <Box style={{ padding: '10px 14px', fontSize: 13 }}>
              <Row cells={[['セッション', '1fr'], ['#2483', '1fr', 'mono']]} />
              <Row cells={[['開始', '1fr'], ['13:42:08', '1fr', 'mono']]} />
              <Row cells={[['最大開度', '1fr'], ['acc 80% / brk 70%', '1fr', 'mono']]} />
            </Box>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, flex: 1 }}>
              {showPause && (
                <Btn big style={{ flex: 1 }} onClick={() => setPaused(p => !p)}>
                  {paused ? '▶ 再開' : '⏸ 一時停止'}
                </Btn>
              )}
              <Btn danger big style={{ flex: 1 }} onClick={() => setConfirmStop(true)}>■ 走行終了</Btn>
            </div>
          </div>
        </div>

      </div>
    </Frame>
    {confirmStop && (
      <ConfirmStopPopup
        message="走行を終了しますか？"
        onYes={() => setConfirmStop(false)}
        onNo={() => setConfirmStop(false)}
      />
    )}
    </div>
  );
}

// ── A5 Minimal — distraction-free, hero number + slim graph
function AutoDriveE({ state }) {
  return (
    <Frame state={state || 'RUNNING'} screen="自動走行 · ミニマル" activeNav="auto">
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%', justifyContent: 'center', alignItems: 'center', gap: 22 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 24 }}>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 14, color: INK_SOFT }}>基準</div>
            <div style={{ fontSize: 56, fontFamily: 'monospace', color: INK_SOFT, lineHeight: 1 }}>60.0</div>
          </div>
          <div style={{ fontSize: 60, color: INK_MUTE }}>→</div>
          <div>
            <div style={{ fontSize: 14, color: INK_SOFT }}>実車速 [km/h]</div>
            <div style={{ fontSize: 140, fontWeight: 800, lineHeight: 1 }}>62.4</div>
          </div>
        </div>
        <Box label="走行トレース" style={{ width: '76%', padding: 12 }}>
          <SpeedGraph width="100%" height={180} progress={0.42} />
        </Box>
        <div style={{ width: '76%' }}>
          <TimeProgress elapsed={760} total={1800} />
        </div>
        <div style={{ display: 'flex', gap: 18, alignItems: 'center' }}>
          <Pill accent="RUNNING">RUNNING · WLTP_Class3</Pill>
          <Btn danger big>■ 停止</Btn>
        </div>
      </div>
    </Frame>
  );
}

Object.assign(window, { AutoDriveA, AutoDriveB, AutoDriveC, AutoDriveD, AutoDriveE });
