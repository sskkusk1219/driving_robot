# 技術仕様書 (Architecture Design Document)

## テクノロジースタック

### 言語・ランタイム

| 技術 | バージョン | 選定理由 |
|------|-----------|----------|
| Python | 3.13 | asyncioによる50ms制御ループ、豊富な科学計算・通信ライブラリ |
| PostgreSQL | 15 | 時系列ログの高速書き込み・検索、JSON型でプロファイル保存可能 |

### フレームワーク・ライブラリ

| 技術 | バージョン | 用途 | 選定理由 |
|------|-----------|------|----------|
| FastAPI | 最新安定版 | Web APIサーバー | asyncio対応、WebSocket、自動APIドキュメント生成 |
| uvicorn | 最新安定版 | ASGIサーバー | FastAPIと組み合わせで高パフォーマンス |
| pymodbus | 3.x | Modbus RTU通信 | asyncio対応、Python製Modbus実装のデファクトスタンダード |
| python-can | 4.x | CAN bus通信 | Kvaser backendに対応 |
| asyncpg | 最新安定版 | PostgreSQL非同期ドライバ | asyncio対応で高速書き込み |
| lgpio | 最新安定版 | GPIO制御 | AC UPS接点出力によるAC断検知・非常停止割り込み。RPi.GPIO の後継（Raspberry Pi OS Bookworm以降の推奨ライブラリ） |
| numpy | 最新安定版 | 運転モデル補間 | 高速な2次元グリッド補間 |
| scipy | 最新安定版 | 運転モデル補間 | RegularGridInterpolator |
| gzip / shutil | 標準ライブラリ | ログアーカイブ圧縮 | 追加インストール不要 |
| pydantic | v2 | データバリデーション | FastAPIと統合、型安全なAPI |

### 開発ツール

| 技術 | バージョン | 用途 | 選定理由 |
|------|-----------|------|----------|
| pytest | 最新安定版 | ユニット・統合テスト | Python標準テストフレームワーク |
| pytest-asyncio | 最新安定版 | 非同期テスト | asyncioコルーチンのテスト対応 |
| ruff | 最新安定版 | Linter / Formatter | 高速、設定簡単 |
| mypy | 最新安定版 | 型チェック | 実行前のバグ検出 |

---

## アーキテクチャパターン

### レイヤードアーキテクチャ

```
┌─────────────────────────────────────────┐
│   Webレイヤー (FastAPI)                   │  ← HTTP / WebSocket
├─────────────────────────────────────────┤
│   アプリケーションレイヤー                  │  ← ユースケース・状態管理
│   RobotController / SessionManager       │
├─────────────────────────────────────────┤
│   ドメインレイヤー                          │  ← 制御ロジック・安全監視
│   FeedforwardController / PIDController  │
│   CalibrationManager / SafetyMonitor     │
├─────────────────────────────────────────┤
│   インフラレイヤー                          │  ← HW抽象・DB・ファイルI/O
│   ActuatorDriver / CANReader             │
│   LogWriter / ArchiveManager             │
└─────────────────────────────────────────┘
```

#### Webレイヤー
- **責務**: HTTPリクエスト受付、WebSocket配信、入力バリデーション
- **許可**: アプリケーションレイヤーの呼び出しのみ
- **禁止**: ドメインロジック・DBへの直接アクセス

#### アプリケーションレイヤー
- **責務**: ユースケースの調整、システム状態機械の管理
- **許可**: ドメインレイヤー・インフラレイヤーの呼び出し
- **禁止**: HTTP/WebSocketプロトコルへの依存

#### ドメインレイヤー
- **責務**: 制御アルゴリズム、安全監視、キャリブレーションロジック
- **許可**: インフラレイヤー（HW抽象クラス）の呼び出し
- **禁止**: DBへの直接アクセス、HTTP依存

#### インフラレイヤー
- **責務**: ハードウェア通信、DB書き込み、ファイルI/O
- **許可**: 外部リソース（Modbus/CAN/PostgreSQL/GPIO）への直接アクセス
- **禁止**: ビジネスロジックの実装

---

### 非同期実行アーキテクチャ

Python asyncioのイベントループで全コンポーネントを並列実行します。

```
asyncio イベントループ
│
├── 制御タスク（50ms周期）
│   ├── CAN車速受信
│   ├── アクセル位置指令送信（ttyUSB0）
│   └── ブレーキ位置指令送信（ttyUSB1）
│
├── ログタスク（100ms周期）
│   └── PostgreSQL非同期書き込み
│
├── WebSocketタスク（100ms周期）
│   └── リアルタイムデータ配信
│
├── 安全監視タスク（常時）
│   ├── GPIO割り込み（非常停止）
│   ├── GPIO割り込み（AC電源断）
│   └── 過電流監視
│
└── FastAPI（HTTPリクエスト処理）
```

**50ms制御ループの実装方針**:
- `asyncio.create_task()` + `asyncio.sleep(0.05)` ではなく
- `asyncio.get_event_loop().run_forever()` + `loop.call_later(0.05, ...)` を使用
- アクチュエータへの2軸同時送信は `asyncio.gather()` で並列実行

---

## データ永続化戦略

### ストレージ方式

| データ種別 | ストレージ | フォーマット | 保持期間 |
|-----------|----------|-------------|---------|
| 車両プロファイル | PostgreSQL | テーブル (JSON列含む) | 無期限 |
| キャリブレーションデータ | PostgreSQL | テーブル | 無期限（最新版） |
| 走行モード定義 | PostgreSQL + CSV | テーブル + 元CSVファイル | 無期限 |
| アクティブ走行ログ | PostgreSQL | drive_logs テーブル | 3ヶ月 |
| アーカイブログ | 外付けUSB SSD | CSV + gzip圧縮 | 容量80%まで |
| 運転モデル | ファイル (`.pkl`) | numpy/pickle形式 | プロファイルに紐づく |
| システム状態（シャットダウン時） | ファイル | JSON | 起動時に参照 |

### バックアップ戦略

- **アクティブログ**: PostgreSQLのWALにより耐障害性確保
- **プロファイル**: 変更時に `config/profiles/` へJSONエクスポート（バージョン管理可能）
- **アーカイブ**: USB SSD（外付け）への定期移行で内蔵SSDを保護
- **システム状態**: シャットダウン時に `data/system_state.json` へ保存

### PostgreSQLインデックス設計

```sql
-- ログ検索の高速化（セッション・時刻でのレンジ検索）
CREATE INDEX idx_drive_logs_session_timestamp
    ON drive_logs (session_id, timestamp DESC);

-- セッション一覧の高速取得
CREATE INDEX idx_drive_sessions_started_at
    ON drive_sessions (started_at DESC);

-- 3ヶ月アーカイブ対象の特定
CREATE INDEX idx_drive_sessions_ended_at
    ON drive_sessions (ended_at ASC);
```

---

## ディレクトリ・プロセス構成

```
driving_robot/
├── src/
│   ├── web/                  # Webレイヤー
│   │   ├── app.py            # FastAPIアプリ定義
│   │   ├── routers/          # APIルーター
│   │   └── static/           # フロントエンド (HTML/JS/CSS)
│   ├── app/                  # アプリケーションレイヤー
│   │   ├── robot_controller.py
│   │   └── session_manager.py
│   ├── domain/               # ドメインレイヤー
│   │   ├── control/
│   │   │   ├── feedforward.py
│   │   │   ├── pid.py
│   │   │   └── drive_loop.py
│   │   ├── calibration.py
│   │   ├── learning_drive.py
│   │   └── safety_monitor.py
│   ├── infra/                # インフラレイヤー
│   │   ├── actuator_driver.py
│   │   ├── can_reader.py
│   │   ├── gpio_monitor.py
│   │   ├── log_writer.py
│   │   ├── archive_manager.py
│   │   └── db.py
│   └── models/               # データモデル (dataclass / pydantic)
│       ├── profile.py
│       ├── calibration.py
│       ├── drive_log.py
│       ├── driving_mode.py
│       └── system_state.py
├── config/
│   ├── can/                  # DBCファイル（自作）
│   ├── profiles/             # 車両プロファイルJSONバックアップ
│   └── settings.toml         # システム設定（ポート・閾値など）
├── data/
│   ├── models/               # 運転モデル (.pkl)
│   └── system_state.json     # シャットダウン時状態保存
├── tests/
│   ├── unit/
│   ├── integration/
│   └── hardware/             # 実機テスト（手動実行）
├── scripts/
│   ├── setup_db.py           # DB初期化
│   ├── setup_env.sh          # 仮想環境・依存関係セットアップ
│   └── start.sh              # システム起動スクリプト
└── docs/
```

---

## パフォーマンス要件

### レスポンスタイム

| 操作 | 目標時間 | 測定方法 |
|------|---------|---------|
| 制御ループ1周期 | 50ms以内 | asyncio ループ計測 |
| ログ書き込み（100ms周期） | 5ms以内 | asyncpg INSERT計測 |
| WebSocket配信遅延 | 100ms以内 | クライアント受信時刻との差分 |
| GUI起動（電源ON後） | 60秒以内 | 起動スクリプト計測 |
| キャリブレーション完了 | 60秒以内 | 両軸合計 |

### リソース使用量（Raspberry Pi 5 16GB）

| リソース | 上限 | 理由 |
|---------|------|------|
| CPU（制御ループ） | 20%以内 | 他プロセスへの影響を最小化 |
| 制御ループメモリ | 512MB以内 | ログバッファ含む |
| 内蔵SSD（PostgreSQL） | 3ヶ月分：推定20GB以内（マージン込み） | 最悪ケース: 100ms×10h×5回/日×90日=16.2GB |
| 制御ループジッタ | ±5ms以内 | 50ms周期の安定性確保 |

### 推定ログ容量計算

```
1レコードサイズ: 約100バイト（8フィールド × 8バイト + オーバーヘッド）
100ms周期 → 10レコード/秒

【典型ケース: 8h × 3走行/日】
1走行8時間: 10 × 3600 × 8 = 288,000レコード ≈ 28.8MB
1日3走行: 86.4MB
3ヶ月(90日): 86.4 × 90 ≈ 7.8GB

【最悪ケース: 10h × 5走行/日（PRD「連続稼働10時間以上」準拠）】
1走行10時間: 10 × 3600 × 10 = 360,000レコード ≈ 36MB
1日5走行: 180MB
3ヶ月(90日): 180 × 90 = 16.2GB（PostgreSQL）

→ 内蔵SSD容量要件: 最悪ケース16.2GBに対し20GBマージンを確保
→ 3ヶ月を超えたログはアーカイブして外付けUSB SSDで管理
```

---

## ハードウェア構成

### Raspberry Pi 5 接続構成

```
Raspberry Pi 5 (16GB)
│
├── USB (ttyUSB0)  →  USB-RS485変換ケーブル  →  P-CON-CB #1 (アクセル, SLAVE_ID=1)
│                                                 └→ IAI RCP6-ROD (アクセル)
│
├── USB (ttyUSB1)  →  USB-RS485変換ケーブル  →  P-CON-CB #2 (ブレーキ, SLAVE_ID=1)
│                                                 └→ IAI RCP6-ROD (ブレーキ)
│
├── USB            →  Kvaser USB-CAN         →  シャシダイナモ CAN bus
│
├── GPIO17 (IN)    →  非常停止スイッチ #1 (シャシダイナモ室)  ← 物理ピン11、NC接点、プルアップ、HIGH=停止（RISING検知）
│                   →  非常停止スイッチ #2 (操作エリア)  ← 並列接続
│                      LOW=通常（NC接点閉→GND）、HIGH=停止（NC接点開→プルアップ有効、断線時も停止）
├── GPIO27 (IN)    →  AC UPS 接点出力（AC断検知）  ← 物理ピン13、プルアップ、LOW=AC断 [要確認: AC UPS機種確定後に更新]
│
└── AC UPS (TBD)   →  5V PSU  →  Raspberry Pi 本体 + 内蔵SSD
                    →  24V PSU →  P-CON-CB #1 / #2
                    └→ AC断時に両系統バックアップ、接点出力でAC断をRPiに通知
```

### Modbus RTU 通信設定

| 項目 | 値 |
|------|---|
| ボーレート | 38400 bps（P-CON-CB実機確認値） |
| データビット | 8 |
| パリティ | なし |
| ストップビット | 1 |
| アクセル SLAVE_ID | 1（ttyUSB0） |
| ブレーキ SLAVE_ID | 1（ttyUSB1）※各軸が独立した RS-485 バスのため両軸とも 1 |

### CAN 通信・配線設定

#### ノード構成

| 機器 | CAN ドライバ | インターフェース | ビットレート |
|------|------------|----------------|------------|
| RPi3B (driving_simulator) | SocketCAN (MCP2515 HAT) | `can0` | 500kbps |
| RPi5 (driving_robot) | Kvaser canlib (usbcanII) | `/dev/usbcanII0` | 500kbps |

#### Kvaser USB-CAN の注意点

- Kvaser Memorator は **SocketCAN ではなく Kvaser canlib 経由**でアクセスする
- そのため `ip link show` の出力に `can0` などのインターフェースは**表示されない**（正常動作）
- デバイス認識確認は `listChannels` コマンドを使用し、`/dev/usbcanII0`, `/dev/usbcanII1` が表示されることを確認する
- 実行には `sudo` が必要（udev rules 未設定の場合）

#### 異電源間の CAN 配線注意点（RPi3B ↔ RPi5）

- **GND 接続必須**: 別電源のノード間は CANH/CANL だけでなく GND も接続しなければ通信できない
  - Kvaser DB9 ピン3(GND) ↔ MCP2515 HAT GND を配線すること
- **終端抵抗**: 2ノード構成では両端末ノードそれぞれに 120Ω の終端抵抗が必要
  - MCP2515 HAT 側: ジャンパで内蔵終端を有効化
  - Kvaser Memorator 側: 終端内蔵なし → DB9 ピン7(CANH) と ピン2(CANL) の間に 120Ω を外付け
  - **確認方法**: CANH-CANL 間をテスターで測定 → **約60Ω** が正常値（120Ω × 2個並列 = 60Ω）

---

## セキュリティアーキテクチャ

### ネットワークアクセス制御

- **ローカルLAN限定**: FastAPIをバインドするネットワークインターフェースをLAN側のみに制限
- **ポート**: HTTP **8080**（デフォルト固定、`config/settings.toml` の `server.port` で変更可能）
- **認証なし**: 同一LAN内からの接続を信頼する（シャシダイナモ室の閉じたネットワーク）

### データ保護

- **機密情報**: 環境変数または `config/settings.toml`（gitignore対象）で管理
- **PostgreSQL接続**: ローカルホスト接続のみ（ソケット認証）
- **DBCファイル**: `config/can/` に配置、gitignore対象外（バージョン管理）

### 入力検証

- **APIリクエスト**: Pydanticモデルで自動バリデーション
- **CSVアップロード**: ヘッダー・数値範囲・時刻単調増加を検証
- **プロファイル設定値**: 開度0-100%・ゲイン正数・閾値正数をバリデーション

---

## スケーラビリティ設計

### データ増加への対応

- **3ヶ月超ログ**: 内蔵SSD使用率が閾値（80%）を超えた場合に `ArchiveManager` が古いレコードからCSV+gzip圧縮してUSB SSDへ移行（常時起動ではないため定期実行ではなく容量トリガー）
- **USB SSD 80%超**: 最古のアーカイブから自動削除
- **車両プロファイル数**: 上限なし（PostgreSQLの行数制限のみ）
- **走行モード数**: 上限なし（CSVファイルサイズに依存）

### 機能拡張性

- **外部API（Post-MVP）**: FastAPIルーターを追加するだけで拡張可能
- **新しいアクチュエータ軸**: `ActuatorDriver` を継承してプラグイン的に追加可能
- **新しい車速ソース**: `CANReader` を抽象化（CAN以外にもOBD2等を将来追加可能）

---

## テスト戦略

### ユニットテスト（`tests/unit/`）

- **フレームワーク**: pytest + pytest-asyncio
- **対象**:
  - PIDController（ステップ応答・積分リセット・ゲイン計算）
  - FeedforwardController（グリッド補間精度）
  - CalibrationManager（バリデーションロジック）
  - SafetyMonitor（閾値判定・タイマー）
  - ArchiveManager（アーカイブ判定・削除ロジック）
- **カバレッジ目標**: ドメインレイヤー 80%以上
- **モック**: ハードウェアドライバはすべてモック化

### 統合テスト（`tests/integration/`）

- **対象**:
  - RobotController 状態遷移（モックHWで全遷移を検証）
  - LogWriter ↔ PostgreSQL（ローカルDBへの実書き込み）
  - FastAPI ↔ RobotController（エンドポイント疎通）
- **環境**: テスト用PostgreSQLデータベース（本番と分離）

### ハードウェア結合テスト（`tests/hardware/`、手動実行）

- アクチュエータ単体Modbus通信（位置指令・読み取り）
- CAN受信（シャシダイナモまたは模擬信号発生器）
- 非常停止GPIO割り込み動作確認
- AC UPS接点出力によるAC断検知確認
- AC電源断シーケンス（実際にコンセントを抜いて確認）

---

## 技術的制約

### 環境要件

- **OS**: Raspberry Pi OS 64-bit (Bookworm以降)
- **ハードウェア**: Raspberry Pi 5 (4GB以上推奨、16GB使用)
- **Python**: 3.13（仮想環境 `.venv` で管理、グローバルインストール禁止）
- **PostgreSQL**: 15（systemdサービスとして起動）
- **USB接続**: ttyUSB0・ttyUSB1 が安定してデバイスに割り当てられること
  - udev rules で固定割り当てを推奨（シリアル番号でデバイスを固定）
- **CAN**: Kvaser Linux ドライバインストール済み
- **AC UPS**: AC断後 **30秒以上** のバックアップ給電が可能な機種を選定すること
  - 根拠: home_return() + PostgreSQL正常終了 + シャットダウンを30秒以内に完了する設計

### パフォーマンス制約

- 50ms制御ループのジッタ: Raspberry Pi OSはリアルタイムOSではないため±5ms程度を許容
- Modbus RTU応答時間（MJ0162-12A 表4.1-1より）:
  - 内部処理時間（位置・ステータスレジスタ）: 最大 1ms
  - 従局トランスミッター活性化最小遅延（Param No.17）: 初期値 5ms（要チューニング、縮小可能）
  - レスポンス後インターメッセージギャップ: 1ms
  - 合計レスポンス遅延: 最大 7ms（Param No.17 デフォルト時）

**制御ループのタイムバジェット（38,400bps、2軸、FC03で6レジスタ読み取り）**:

| 処理 | 時間 |
|------|------|
| FC03 クエリー送信（8バイト × 0.286ms/byte） | 2.3ms |
| P-CON-CB 内部処理 + Param No.17 遅延 | 最大 6ms |
| FC03 レスポンス受信（17バイト × 0.286ms/byte） | 4.9ms |
| インターメッセージギャップ | 1ms |
| **1軸あたり小計** | **約 14ms** |
| **2軸合計（RS-485 逐次）** | **約 28ms** |

> ⚠️ 38,400bps では 2 軸逐次読み取りだけで約 28ms かかる。
> 10ms・20ms ループは不可能。**50ms ループ（20Hz）を推奨**。
> 位置指令（FC10）は値が変化した場合のみ送信することで実質的なレイテンシを低減する。
> Param No.17 を 1ms に縮小すると約 4ms 短縮可能（実機チューニングで検証）。

### python-can aarch64 既知バグ（要パッチ）

python-can 4.x を aarch64 (Raspberry Pi 5) で使用する場合、以下の2つのバグをパッチする必要がある。
パッチは `.venv` 内のファイルを直接修正する。`pip install --upgrade python-can` で上書きされたら再パッチが必要。

**バグ1: `ctypes.c_long` のサイズ不一致**

- 場所: `.venv/lib/.../can/interfaces/kvaser/canlib.py` line 509 付近
- 原因: aarch64 では `ctypes.c_long` が 8バイト。canlib ioctl に `c_long` + `size=4` を渡すと `canERR_PARAM`
- 修正: `ctypes.c_long(TIMESTAMP_RESOLUTION)` → `ctypes.c_uint(TIMESTAMP_RESOLUTION)`、`4` → `ctypes.sizeof(ctypes.c_uint)`

**バグ2: `canIOCTL_SET_LOCAL_TXACK` 未サポートエラー**

- 場所: 同ファイルの `canIoCtlInit` 呼び出し部
- 原因: Kvaser Memorator は `canIOCTL_SET_LOCAL_TXACK` 未サポートで `canERR_PARAM` を返す
- 注意: `canIoCtlInit` と `canIoCtl` は ctypes のキャッシュにより同一関数オブジェクトを返すため、
  `errcheck` が `__check_status_operation` に上書きされる。
  `except CANLIBInitializationError` では捕捉できず `except CANLIBError` が必要
- 修正: `canIoCtlInit(SET_LOCAL_TXACK, ...)` を `try/except CANLIBError` で囲む

### ネットワーク制約

- ローカルLAN（有線LANケーブル推奨、Wi-Fi は不安定なため非推奨）
- クラウド・インターネット接続不要

---

## 依存関係管理

| ライブラリ | 用途 | バージョン管理方針 |
|-----------|------|-------------------|
| fastapi | WebAPI | `>=0.100.0` 下位互換性あり |
| uvicorn | ASGIサーバー | `>=0.20.0` |
| pymodbus | Modbus RTU | `>=3.0.0` 3.x APIに依存 |
| python-can | CAN通信 | `>=4.0.0` Kvaser backend |
| asyncpg | PostgreSQL | `>=0.28.0` |
| RPi.GPIO | GPIO | `>=0.7.0` |
| numpy | 数値計算 | `>=1.25.0` |
| scipy | 補間 | `>=1.11.0` |
| pydantic | バリデーション | `>=2.0.0` v2 API |
| pytest | テスト | `>=7.0.0` |
| pytest-asyncio | 非同期テスト | `>=0.21.0` |
| ruff | Lint/Format | `>=0.1.0` |

**管理方針**:
- `pyproject.toml` で最小バージョンを指定（Python 3.13 対応のモダン構成）
- 再現性のため `pip freeze > requirements.lock` を使用
- ライブラリは `.venv` 内にのみインストール（グローバル禁止）
